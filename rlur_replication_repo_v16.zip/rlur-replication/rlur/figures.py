"""Figures 1-6. All data figures are drawn from the household file via run_all.py."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle
import numpy as np

from .data import CASES, STATES, SHORT, ROOT

FIG = ROOT / "outputs" / "figures"
FIG.mkdir(parents=True, exist_ok=True)
GEO = ROOT / "geo"

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9, "axes.titlesize": 9.5,
    "axes.titleweight": "bold", "axes.labelsize": 9, "axes.spines.top": False,
    "axes.spines.right": False, "savefig.dpi": 300, "savefig.bbox": "tight",
})
INK = "#1f2a36"
BLUE = "#2f5d8a"
ORANGE = "#c8691c"
GREY = "#8a949e"
PEN = "#e9eef3"   # Peninsular shading
EAST = "#f6efe6"  # East Malaysia shading


def _save(fig, name):
    fig.savefig(FIG / name)
    plt.close(fig)


# --------------------------------------------------------------------------------------
# Figure 1. Conceptual framework (schematic, no data)
# --------------------------------------------------------------------------------------
def fig1_framework():
    fig, ax = plt.subplots(figsize=(7.4, 4.3))
    ax.set_xlim(0, 100); ax.set_ylim(0, 62); ax.axis("off")

    def box(x, y, w, h, title, body, fc):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.3,rounding_size=1.0",
                                    fc=fc, ec=INK, lw=0.8))
        ax.text(x + w / 2, y + h - 1.6, title, ha="center", va="top", fontsize=7.6,
                fontweight="bold", color=INK, linespacing=1.15)
        nl = title.count("\n")
        ax.text(x + w / 2, y + h - 5.6 - 3.0 * nl, body, ha="center", va="top", fontsize=6.3,
                color=INK, linespacing=1.3)

    def arrow(x0, y0, x1, y1, ls="-", c=INK):
        ax.annotate("", xy=(x1, y1), xytext=(x0, y0),
                    arrowprops=dict(arrowstyle="-|>", lw=0.9, color=c, ls=ls,
                                    shrinkA=0, shrinkB=0, mutation_scale=9))

    box(0.5, 18, 19.5, 33, "Social structure",
        "Village leadership\n(ketua kampung,\nJKKK)\n\nKinship and adat\n\nSpatial proximity\n\nDefines reference\ngroups and weights",
        "#eef2f6")
    box(27, 42, 27, 17, "Global social interaction",
        "Village-wide attitude\nInformational learning\nNormative conformity\nMarket thickness", "#e3ecf5")
    box(27, 12, 27, 17, "Local social interaction",
        "Kin, friends and neighbours\nBonding social capital\nKin as residual claimants", "#e3ecf5")
    box(77, 25, 22, 18, "Circulation of the\nresidential land\nuse right", "", "#f3e7e7")
    box(54.5, 0.5, 20, 11, "Tenure regime",
        "Legal friction by case\n(PRT, Institutional Theory)", "#f6efe6")
    box(77.5, 0.5, 22, 18, "Household attributes",
        "Age, education, occupation,\nfamily size, wealth,\nhomestead area, urban\nand land-market\nexperience (TPB, PRT, SCT)", "#f6efe6")

    arrow(20.4, 41, 26.6, 48); arrow(20.4, 28, 26.6, 21)
    arrow(54.4, 50.5, 76.6, 38.5); ax.text(66.5, 46.6, "H1 (+)", fontsize=7.6, fontweight="bold", color=BLUE)
    arrow(54.4, 20.5, 76.6, 30.0); ax.text(66.5, 21.0, "H2 (+)", fontsize=7.6, fontweight="bold", color=BLUE)
    arrow(88.5, 18.9, 88.5, 24.6)
    arrow(62.0, 11.4, 63.0, 24.9, ls="--", c=ORANGE)
    arrow(66.0, 11.4, 64.5, 44.0, ls="--", c=ORANGE)
    ax.text(57.4, 16.0, "RQ3", fontsize=6.8, color=ORANGE, style="italic", fontweight="bold")
    _save(fig, "fig1_conceptual_framework.png")


# --------------------------------------------------------------------------------------
# Figure 2. Study location
# --------------------------------------------------------------------------------------
def _scalebar(ax, lon0, lat0, km, lat_ref):
    deg = km / (111.32 * np.cos(np.radians(lat_ref)))
    ax.plot([lon0, lon0 + deg], [lat0, lat0], color=INK, lw=2.2, solid_capstyle="butt")
    ax.text(lon0 + deg / 2, lat0 + 0.12, f"{km} km", ha="center", va="bottom", fontsize=7)


def _north(ax, x, y, size=0.5):
    ax.annotate("N", xy=(x, y + size), xytext=(x, y), ha="center", va="bottom", fontsize=8,
                fontweight="bold", arrowprops=dict(arrowstyle="-|>", color=INK, lw=1))


REGIME = {1: "Group settlement (GSA 1960, FELDA)", 2: "Malay Reserve Land",
          3: "NLC alienated land, urban fringe", 4: "NLC alienated land, mixed",
          5: "Sabah native title", 6: "Sabah native and communal title",
          7: "Sarawak NCR, Section 6 communal grant"}
LABEL_OFFSET = {1: (0.12, -0.05, "left"), 2: (0.12, 0.12, "left"), 3: (0.15, -0.28, "left"),
                4: (-0.12, -0.18, "right"), 5: (0.18, 0.12, "left"), 6: (-0.18, -0.25, "right"),
                7: (0.18, 0.0, "left")}


def fig2_location(df):
    import geopandas as gpd
    sea = gpd.read_file(GEO / "sea_countries_ne50m.geojson")
    st = gpd.read_file(GEO / "malaysia_states_ne10m.geojson")
    from .data import kampungs
    site = kampungs().groupby("case")[["lat", "lon"]].mean()

    fig = plt.figure(figsize=(7.4, 6.7))
    gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.25], width_ratios=[1, 1.3],
                          hspace=0.30, wspace=0.14)
    axA = fig.add_subplot(gs[0, 0]); axC = fig.add_subplot(gs[0, 1])
    axB = fig.add_subplot(gs[1, 0]); axL = fig.add_subplot(gs[1, 1])

    sea.plot(ax=axA, color="#e3e3e3", edgecolor="white", lw=0.4)
    sea[sea.ADMIN == "Malaysia"].plot(ax=axA, color="#9fb6cc", edgecolor=INK, lw=0.4)
    axA.set_xlim(92, 128); axA.set_ylim(-9, 23); axA.set_facecolor("#f4f8fb")
    for (x0, x1, y0, y1) in [(99.4, 104.6, 1.1, 6.9), (109.4, 119.6, 0.6, 7.6)]:
        axA.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, ec="#b23a3a", lw=1))
    for name, (x, y) in {"THAILAND": (100.5, 15.5), "INDONESIA": (113.5, -3.8),
                         "PHILIPPINES": (122.5, 13.5), "VIETNAM": (108.4, 14.6),
                         "MALAYSIA": (106.5, 8.0)}.items():
        axA.text(x, y, name, fontsize=6.3, ha="center",
                 color=INK if name == "MALAYSIA" else GREY,
                 fontweight="bold" if name == "MALAYSIA" else None)
    axA.text(111.5, 10.5, "South China Sea", fontsize=6, style="italic", color=GREY, ha="center")
    axA.set_title("(a) Malaysia in Southeast Asia", loc="left")
    axA.set_xticks([]); axA.set_yticks([]); axA.set_xlabel(""); axA.set_ylabel("")
    _north(axA, 125.5, 17.5, 3.0)

    def panel(ax, xlim, ylim, cases, title, bar_km, bar_pos):
        sea.plot(ax=ax, color="#e9e9e9", edgecolor="white", lw=0.4)
        st.plot(ax=ax, color="#f4f1ea", edgecolor="#8a8a8a", lw=0.5)
        ax.set_xlim(*xlim); ax.set_ylim(*ylim); ax.set_facecolor("#f4f8fb")
        for c in cases:
            lat, lon = site.loc[c]
            ax.scatter(lon, lat, s=55, color=BLUE if c <= 4 else ORANGE, ec="white", lw=0.8, zorder=4)
            dx, dy, ha = LABEL_OFFSET[c]
            ax.text(lon + dx, lat + dy, f"{c} {CASES[c]}", fontsize=6.9, ha=ha, va="center",
                    zorder=5, bbox=dict(fc="white", ec="none", alpha=0.8, pad=0.5))
        _scalebar(ax, *bar_pos, bar_km, 2.0)
        ax.set_title(title, loc="left"); ax.tick_params(labelsize=6.5)
        ax.set_xlabel("Longitude (\u00b0E)", fontsize=7); ax.set_ylabel("Latitude (\u00b0N)", fontsize=7)

    panel(axC, (109.4, 119.6), (0.6, 7.6), [5, 6, 7], "(c) Sabah and Sarawak: cases 5\u20137",
          200, (110.0, 1.0))
    _north(axC, 118.9, 6.6, 0.55)
    panel(axB, (99.4, 104.6), (1.1, 6.9), [1, 2, 3, 4], "(b) Peninsular Malaysia: cases 1\u20134",
          100, (99.8, 1.5))
    _north(axB, 104.1, 6.0, 0.45)

    axL.axis("off")
    axL.set_title("(d) Cases and tenure regimes", loc="left")
    for i, c in enumerate(range(1, 8)):
        yy = 0.93 - i * 0.125
        axL.scatter(0.03, yy, s=40, color=BLUE if c <= 4 else ORANGE, ec="white", transform=axL.transAxes)
        axL.text(0.08, yy + 0.022, f"{c}  {CASES[c]}, {STATES[c]}", fontsize=7.2, fontweight="bold",
                 transform=axL.transAxes, va="center")
        axL.text(0.08, yy - 0.032, REGIME[c], fontsize=6.8, transform=axL.transAxes, va="center",
                 color="#333")
    fig.text(0.01, 0.0,
             "Coordinate system: WGS 84 (EPSG:4326), geographic. Boundaries: Natural Earth 1:10m states, 1:50m countries. "
             "Markers show approximate case\nlocations only; household and kampung positions are not shown, to protect respondent confidentiality.",
             fontsize=6.2, color="#444")
    _save(fig, "fig2_study_location.png")


# --------------------------------------------------------------------------------------
# Figure 3. Sample characteristics
# --------------------------------------------------------------------------------------
def fig3_sample(df, R):
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.7), gridspec_kw=dict(width_ratios=[0.85, 1, 1.35]))
    y = df.Y.value_counts().reindex([0, 1])
    axs[0].bar(["Not\ncirculating", "Circulating"], y.values, color=[GREY, BLUE], width=0.6)
    for i, v in enumerate(y.values):
        axs[0].text(i, v + 4, f"{v}\n({100 * v / len(df):.1f}%)", ha="center", fontsize=7)
    axs[0].set_ylim(0, 260); axs[0].set_ylabel("Households")
    axs[0].set_title("(a) Circulation decision", loc="left")

    occ = df.occupation_category.value_counts().sort_index()
    labs = ["Farming", "Mixed\nlivelihood", "Non-farm"]
    axs[1].bar(labs, occ.values, color=["#6c8fb0", "#a7bdd2", "#d6dfe8"], ec=INK, lw=0.5, width=0.6)
    for i, v in enumerate(occ.values):
        axs[1].text(i, v + 3, f"{v}\n({100 * v / len(df):.1f}%)", ha="center", fontsize=7)
    axs[1].set_ylim(0, 210); axs[1].set_title("(b) Occupation of head", loc="left")

    bins = np.linspace(0, 1, 26)
    axs[2].hist(df.GSIs.dropna(), bins=bins, alpha=0.35, color=BLUE)
    axs[2].hist(df.GSIs.dropna(), bins=bins, histtype="step", lw=1.3, color=BLUE,
                label=f"GSI*: mean {df.GSIs.mean():.3f}, n = {df.GSIs.notna().sum()}")
    axs[2].hist(df.LSI.dropna(), bins=bins, alpha=0.25, color=ORANGE)
    axs[2].hist(df.LSI.dropna(), bins=bins, histtype="step", lw=1.3, color=ORANGE,
                label=f"LSI: mean {df.LSI.mean():.3f}, n = {df.LSI.notna().sum()}")
    axs[2].set_ylim(0, 75)
    axs[2].set_xlabel("Index value (unit scale)"); axs[2].set_ylabel("Households")
    axs[2].legend(fontsize=6.4, frameon=False, loc="upper left")
    axs[2].set_title("(c) GSI* and LSI distributions", loc="left")
    fig.tight_layout()
    _save(fig, "fig3_sample_characteristics.png")


# --------------------------------------------------------------------------------------
# Figure 4. Standardised effects
# --------------------------------------------------------------------------------------
def fig4_effects(R):
    order = ["GSIs", "LSI", "age", "educ", "cityyr", "fam", "wealth", "area",
             "married", "relig", "health", "occ2", "occ3", "split", "lmrc"]
    lab = {k: SHORT[k] for k in order}
    lab.update({"GSIs": "GSI* (+1 SD)", "LSI": "LSI (+1 SD)"})
    for k in ["age", "educ", "cityyr", "fam", "wealth", "area"]:
        lab[k] += " (+1 SD)"
    for k in ["married", "relig", "health", "occ2", "occ3", "split", "lmrc"]:
        lab[k] += " (0\u21921)"
    fig, ax = plt.subplots(figsize=(6.4, 5.0))
    ypos = np.arange(len(order))[::-1]
    for off, key, col, name in [(0.17, "G", BLUE, "Model 1 (GSI*)"), (-0.17, "L", ORANGE, "Model 2 (LSI)")]:
        S = R["main"][key]["std"]
        for y, k in zip(ypos, order):
            if k not in S:
                continue
            e = S[k]
            filled = e["p"] < 0.05
            ax.plot([100 * e["lo"], 100 * e["hi"]], [y + off] * 2, color=col, lw=1.2)
            ax.scatter(100 * e["eff"], y + off, color=col if filled else "white", ec=col, s=24,
                       zorder=3)
    ax.axvline(0, color=GREY, lw=0.8)
    ax.axhspan(len(order) - 2.5, len(order) - 0.5, color="#f2f5f8", zorder=0)
    ax.set_yticks(ypos); ax.set_yticklabels([lab[k] for k in order], fontsize=7.6)
    ax.set_xlabel("Change in circulation probability (percentage points), 95% CI")
    from matplotlib.lines import Line2D
    ax.legend(handles=[Line2D([], [], color=BLUE, marker="o", lw=1.2, label="Model 1 (GSI*)"),
                       Line2D([], [], color=ORANGE, marker="o", lw=1.2, label="Model 2 (LSI)")],
              frameon=False, fontsize=7.4, loc="lower right")
    ax.text(0.99, 0.995, "Filled marker: p < 0.05", transform=ax.transAxes, ha="right",
            va="top", fontsize=6.8, color="#444")
    _save(fig, "fig4_standardised_effects.png")


# --------------------------------------------------------------------------------------
# Figure 5. Predicted probabilities (probit)
# --------------------------------------------------------------------------------------
def fig5_predicted(df, curves):
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.8), sharey=True)
    for ax, key, var, col, title, xl in [
        (axs[0], "G", "GSIs", BLUE, "(a) Global social interaction", "GSI* (unit scale)"),
        (axs[1], "L", "LSI", ORANGE, "(b) Local social interaction", "LSI")]:
        g, p, lo, hi = curves[key]
        ax.fill_between(g, lo, hi, color=col, alpha=0.18, lw=0)
        ax.plot(g, p, color=col, lw=1.8)
        x = df[var].dropna()
        ax.plot(x, np.full(len(x), -0.02), "|", color=GREY, ms=5, alpha=0.6)
        ax.axhline(df.Y.mean(), color=GREY, ls=":", lw=0.9)
        ax.set_ylim(-0.05, 1.0); ax.set_xlabel(xl); ax.set_title(title, loc="left")
    axs[0].set_ylabel("Average predicted probability")
    axs[1].text(0.02, df.Y.mean() + 0.02, "sample rate", fontsize=6.5, color="#555")
    fig.tight_layout()
    _save(fig, "fig5_predicted_probability.png")


# --------------------------------------------------------------------------------------
# Figure 6. Variation across the seven cases
# --------------------------------------------------------------------------------------
def fig6_cases(R):
    fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.9), sharey=True,
                            gridspec_kw=dict(width_ratios=[1, 1, 1]))
    cases = list(range(1, 8)); y = np.arange(7)[::-1]
    names = [f"{c} {CASES[c]}" for c in cases]
    for ax in axs:
        ax.axhspan(2.5, 6.5, color=PEN, zorder=0); ax.axhspan(-0.5, 2.5, color=EAST, zorder=0)
    rates = R["cases"]["rates"]
    for yy, c in zip(y, cases):
        r = rates[c]
        axs[0].plot([r["lo"], r["hi"]], [yy, yy], color=INK, lw=1.1)
        axs[0].scatter(r["rate"], yy, color=INK, s=20, zorder=3)
    pooled = sum(rates[c]["rate"] * rates[c]["n"] for c in cases) / sum(rates[c]["n"] for c in cases)
    axs[0].axvline(pooled, color=GREY, ls="--", lw=0.8)
    axs[0].set_xlim(0, 1); axs[0].set_xlabel("Circulation rate (95% CI)")
    axs[0].set_title(f"(a) Circulation rate by case\n\u03c7\u00b2({R['cases']['dof']}) = {R['cases']['chi2']:.1f}, p = {R['cases']['p']:.2f}",
                     loc="left", fontsize=8.6)
    for ax, v, col, ttl in [(axs[1], "GSIs", BLUE, "(b) GSI* slope by case"),
                            (axs[2], "LSI", ORANGE, "(c) LSI slope by case")]:
        H = R["hetero"][v]
        for yy, c in zip(y, cases):
            t = H["case"][c]
            ax.plot([t["lo"], t["hi"]], [yy, yy], color=col, lw=1.1)
            ax.scatter(t["b"], yy, color=col, s=20, zorder=3)
        pooled_b = R["main"]["G" if v == "GSIs" else "L"]["coef"][v]["b"]
        ax.axvline(pooled_b, color=GREY, ls="--", lw=0.8); ax.axvline(0, color=GREY, lw=0.6)
        ax.set_xlabel("LPM coefficient (95% CI)")
        ax.set_title(f"{ttl}\nF = {H['wald']['F']:.2f}, p = {H['wald']['p']:.2f}", loc="left", fontsize=8.6)
    axs[0].set_yticks(y); axs[0].set_yticklabels(names, fontsize=7.4)
    axs[0].text(0.98, 6.2, "Peninsular", ha="right", fontsize=6.5, color="#555")
    axs[0].text(0.98, 2.2, "East Malaysia", ha="right", fontsize=6.5, color="#555")
    fig.tight_layout(w_pad=1.6)
    _save(fig, "fig6_case_variation.png")
