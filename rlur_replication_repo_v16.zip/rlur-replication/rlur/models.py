"""All estimators used in the paper.

Linear probability models: OLS with case (site) fixed effects and
cluster-robust standard errors by kampung (G = 42), t distribution with G - 1 df.
"""
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from scipy import stats

from .data import CONTROLS

FE = "C(case)"


def _rhs(main, extra=""):
    terms = list(main) + CONTROLS
    f = " + ".join(terms) + f" + {FE}"
    return f + (f" + {extra}" if extra else "")


def lpm(df, main, extra="", need=None):
    need = list(need or main)
    d = df.dropna(subset=need).copy()
    m = smf.ols(f"Y ~ {_rhs(main, extra)}", d).fit(
        cov_type="cluster", cov_kwds={"groups": d["kampung_id"]}, use_t=True)
    return m


def probit(df, main, need=None):
    need = list(need or main)
    d = df.dropna(subset=need).copy()
    m = smf.probit(f"Y ~ {_rhs(main)}", d).fit(
        disp=0, maxiter=500, cov_type="cluster",
        cov_kwds={"groups": d["kampung_id"]})
    return m


def tidy(m, names):
    ci = m.conf_int()
    out = {}
    for k in names:
        if k in m.params.index:
            out[k] = dict(b=float(m.params[k]), se=float(m.bse[k]),
                          p=float(m.pvalues[k]), lo=float(ci.loc[k, 0]),
                          hi=float(ci.loc[k, 1]))
    return out


def fit_stats(m):
    return dict(n=int(m.nobs), r2=float(m.rsquared),
                clusters=int(m.model.data.frame["kampung_id"].nunique()))


def standardised(m, df, names, binary):
    """Effect of a 1-SD change (continuous) or 0->1 (binary), in probability units."""
    ci = m.conf_int()
    out = {}
    for k in names:
        s = 1.0 if k in binary else float(df.loc[m.model.data.row_labels, k].std())
        out[k] = dict(scale=s, eff=float(m.params[k] * s),
                      lo=float(ci.loc[k, 0] * s), hi=float(ci.loc[k, 1] * s),
                      p=float(m.pvalues[k]))
    return out


def winsorise(df, cols, lo=0.01, hi=0.99):
    w = df.copy()
    for c in cols:
        w[c] = w[c].clip(w[c].quantile(lo), w[c].quantile(hi))
    return w


def probit_summary(m, var):
    me = m.get_margeff(at="overall").summary_frame()
    d = m.model.data.frame
    return dict(n=int(m.nobs), converged=bool(m.mle_retvals["converged"]),
                b=float(m.params[var]), se=float(m.bse[var]), p=float(m.pvalues[var]),
                ame=float(me.loc[var, "dy/dx"]), ame_se=float(me.loc[var, "Std. Err."]),
                ame_p=float(me.loc[var, "Pr(>|z|)"]),
                pseudo_r2=float(m.prsquared), llf=float(m.llf),
                pmin=float(m.predict(d).min()), pmax=float(m.predict(d).max()))


def predicted_curve(m, var, grid, draws=2000, seed=11):
    """Average predicted probability across the sample as `var` is set to each grid value.
    95% band from parametric draws using the cluster-robust covariance."""
    X = np.array(m.model.exog, dtype=float)
    j = m.model.exog_names.index(var)      # `var` enters linearly as one column
    rng = np.random.default_rng(seed)
    B = rng.multivariate_normal(m.params.values, m.cov_params().values, size=draws)
    point, lo, hi = [], [], []
    for g in grid:
        Xg = X.copy(); Xg[:, j] = g
        point.append(stats.norm.cdf(Xg @ m.params.values).mean())
        sims = stats.norm.cdf(Xg @ B.T).mean(axis=0)
        lo.append(np.percentile(sims, 2.5)); hi.append(np.percentile(sims, 97.5))
    return np.array(point), np.array(lo), np.array(hi)


def case_slopes(df, var):
    """Case-specific slopes on `var` from one pooled model (full controls + case FE),
    plus a Wald test that all seven slopes are equal."""
    need = [var]
    d = df.dropna(subset=need).copy()
    for c in range(1, 8):
        d[f"{var}_c{c}"] = d[var] * (d["case"] == c)
    inter = [f"{var}_c{c}" for c in range(1, 8)]
    f = "Y ~ " + " + ".join(inter + CONTROLS) + f" + {FE}"
    m = smf.ols(f, d).fit(cov_type="cluster", cov_kwds={"groups": d["kampung_id"]},
                          use_t=True)
    R = " = ".join(inter)
    w = m.wald_test(R, scalar=True)
    return m, tidy(m, inter), dict(F=float(w.statistic), p=float(w.pvalue),
                                   df_num=int(w.df_num))


def east_interaction(df, var):
    m = lpm(df, [var], extra=f"{var}:east", need=[var])
    return m, tidy(m, [var, f"{var}:east"])


def case_differences(df):
    tab = pd.crosstab(df["case"], df["Y"])
    chi2, p, dof, _ = stats.chi2_contingency(tab)
    rates = df.groupby("case")["Y"].agg(["mean", "size", "sum"])
    rows = {}
    for c, r in rates.iterrows():
        lo, hi = wilson(r["sum"], r["size"])
        rows[int(c)] = dict(rate=float(r["mean"]), n=int(r["size"]), lo=lo, hi=hi)
    return dict(chi2=float(chi2), p=float(p), dof=int(dof), rates=rows)


def wilson(k, n, z=1.96):
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return float(c - h), float(c + h)


def icc_anova(df, y, group):
    d = df.dropna(subset=[y])
    g = d.groupby(group)[y]
    k = g.ngroups; N = len(d)
    n0 = (N - (g.size() ** 2).sum() / N) / (k - 1)
    msb = (g.size() * (g.mean() - d[y].mean()) ** 2).sum() / (k - 1)
    msw = ((d[y] - g.transform("mean")) ** 2).sum() / (N - k)
    return float(max(0.0, (msb - msw) / (msb + (n0 - 1) * msw)))


def morans_i(values, coords, k=4, perms=9999, seed=20261013):
    n = len(values)
    D = np.sqrt(((coords[:, None] - coords[None]) ** 2).sum(-1))
    np.fill_diagonal(D, np.inf)
    W = np.zeros((n, n))
    for i in range(n):
        W[i, np.argsort(D[i])[:k]] = 1

    def I(z):
        z = z - z.mean()
        return n / W.sum() * (z @ W @ z) / (z @ z)

    obs = I(values)
    rng = np.random.default_rng(seed)
    sim = np.array([I(rng.permutation(values)) for _ in range(perms)])
    return dict(I=float(obs), EI=float(-1 / (n - 1)),
                p=float((np.sum(sim >= obs) + 1) / (perms + 1)), n=n, k=k), W
