"""Load the household file and build analysis variables.

Every derived variable is defined here so that tables, figures and the
manuscript all draw on one definition.
"""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"

RENAME = {
    "circulation_DV": "Y",
    "global_social_interaction_GSI": "GSI",
    "local_social_interaction_LSI": "LSI",
    "educational_background": "educ",
    "marriage_status": "married",
    "religious_belief": "relig",
    "self_evaluated_health": "health",
    "city_living_period_yr": "cityyr",
    "family_scale": "fam",
    "household_splitting_son": "split",
    "family_net_wealth_MYR10k": "wealth",
    "homestead_area_m2": "area",
    "land_mgmt_right_circulation": "lmrc",
    "likert_overall_avg_expectation": "avgexp",
    "likert_closegroup_expectation": "closeexp",
    "city_fe": "case",
}

LABELS = {
    "Y": "Circulation of residential land use right (1 = yes)",
    "GSIs": "Global social interaction, GSI* (unit scale)",
    "LSI": "Local social interaction, LSI",
    "age": "Age of household head (years)",
    "educ": "Education (years)",
    "married": "Married (1 = yes)",
    "relig": "Religious belief (1 = yes)",
    "health": "Self-evaluated health (1 = healthy)",
    "cityyr": "City living period (years)",
    "fam": "Family size (members)",
    "split": "Household splitting for a son (1 = yes)",
    "wealth": "Family net wealth (MYR 10,000)",
    "area": "Homestead area (m\u00b2)",
    "lmrc": "Land management right circulation (1 = yes)",
    "avgexp": "Village-wide expectation (Likert 1\u20137)",
    "closeexp": "Close-group expectation (Likert 1\u20137)",
    "occ2": "Mixed livelihood (vs farming)",
    "occ3": "Non-farm (vs farming)",
}

SHORT = {
    "GSIs": "GSI*", "LSI": "LSI", "age": "Age", "educ": "Education",
    "married": "Married", "relig": "Religious belief", "health": "Healthy",
    "cityyr": "City living period", "fam": "Family size",
    "split": "Household splitting", "wealth": "Net wealth",
    "area": "Homestead area", "lmrc": "Land mgmt right circulation",
    "occ2": "Mixed livelihood", "occ3": "Non-farm",
    "avgexp": "Village-wide expectation (1\u20137)",
    "closeexp": "Close-group expectation (1\u20137)",
}

CASES = {
    1: "FELDA Serting Hilir", 2: "Baling", 3: "Permatang Pauh", 4: "Mersing",
    5: "Ranau", 6: "Kg. Sinulihan", 7: "Kapit",
}
STATES = {1: "Negeri Sembilan", 2: "Kedah", 3: "Pulau Pinang", 4: "Johor",
          5: "Sabah", 6: "Sabah", 7: "Sarawak"}

CONTROLS = ["age", "educ", "married", "relig", "health", "cityyr", "occ2", "occ3",
            "fam", "split", "wealth", "area", "lmrc"]


def load() -> pd.DataFrame:
    df = pd.read_csv(DATA / "households.csv").rename(columns=RENAME)
    df["GSIs"] = 2.0 * df["GSI"]            # rescale [0, 0.5] -> [0, 1]
    df["occ2"] = (df["occupation_category"] == 2).astype(int)
    df["occ3"] = (df["occupation_category"] == 3).astype(int)
    df["east"] = (df["case"] >= 5).astype(int)   # Sabah and Sarawak cases
    df["case_name"] = df["case"].map(CASES)
    return df


def kampungs() -> pd.DataFrame:
    return pd.read_csv(DATA / "kampung_centroids_approx.csv")
