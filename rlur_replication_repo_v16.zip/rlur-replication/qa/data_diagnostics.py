"""Data-quality diagnostics. Run before every analysis or on any new data file.

    python qa/data_diagnostics.py [path/to/households.csv]

Reports features that help confirm a file is genuine field data: design
consistency (households per kampung), pile-ups at hard bounds, expected
correlations among household attributes, and whether variables differ
across the seven tenure settings and 42 kampungs. None of these checks is
proof either way; they are prompts to trace values back to questionnaires.
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from rlur.data import RENAME  # noqa: E402

path = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "data" / "households.csv"
df = pd.read_csv(path).rename(columns=RENAME)
out = []
p = out.append

p(f"File: {path}\nHouseholds: {len(df)}\n")
p("1. Design consistency")
kn = df.kampung_id.value_counts()
p(f"   households per case: {df.case.value_counts().sort_index().to_dict()}")
p(f"   households per kampung: min {kn.min()}, median {kn.median():.1f}, max {kn.max()}; "
  f"kampungs with more than 10: {(kn > 10).sum()} (design draws 10 per kampung)")

p("\n2. Pile-ups at bounds (count at bound vs. mean count at the next three values)")
for v in ["age", "educ", "fam", "wealth", "area", "cityyr"]:
    s = df[v].dropna(); lo, hi = s.min(), s.max()
    vals = np.sort(s.round(0).unique())
    near_lo = np.mean([(s.round(0) == x).sum() for x in vals[1:4]])
    near_hi = np.mean([(s.round(0) == x).sum() for x in vals[-4:-1]])
    p(f"   {v:7s} at min {lo:g}: {(s == lo).sum():3d} (neighbours {near_lo:.1f}); "
      f"at max {hi:g}: {(s == hi).sum():3d} (neighbours {near_hi:.1f})")

p("\n3. Correlations expected in rural household data")
for a, b in [("age", "educ"), ("age", "fam"), ("age", "wealth"), ("wealth", "area"),
             ("educ", "cityyr"), ("educ", "wealth")]:
    p(f"   r({a}, {b}) = {df[[a, b]].corr().iloc[0, 1]: .3f}")

p("\n4. Do variables differ across the seven tenure settings? (one-way F test)")
for v in ["Y", "GSI", "LSI", "age", "educ", "wealth", "area", "split", "lmrc"]:
    d = df.dropna(subset=[v])
    r = smf.ols(f"{v} ~ C(case)", d).fit()
    rk = smf.ols(f"{v} ~ C(kampung_id)", d).fit()
    p(f"   {v:7s} case p = {r.f_pvalue:.3f} (R2 {r.rsquared:.3f}); "
      f"kampung R2 {rk.rsquared:.3f} (chance level about {41 / (len(d) - 1):.3f})")

text = "\n".join(out)
print(text)
(ROOT / "outputs").mkdir(exist_ok=True)
(ROOT / "outputs" / "qa_report.txt").write_text(text + "\n")
