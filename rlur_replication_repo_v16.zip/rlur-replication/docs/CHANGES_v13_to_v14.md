# Changes from v13 to v14

The v14 results are estimated directly from the household data file by `run_all.py`. Where the data did not support a v13 claim, the claim was removed or revised, including where a reviewer had asked for it.

## Results that changed

| Item | v13 | v14 (from data) |
|---|---|---|
| GSI\* coefficient, 1 SD effect | 0.844, 11.5 pp | 1.287, 16.5 pp |
| LSI coefficient, 1 SD effect | 0.642, 14.2 pp | 0.501, 11.2 pp |
| Ranking of channels | local larger | global larger on point estimate; difference not significant (p = 0.13) |
| R² | 0.769 / 0.784 | 0.278 / 0.213 |
| Joint model N | 343 | 320 |
| Education, city living period, household splitting | significant | not significant |
| Probit | "quasi-complete separation" | converges; AMEs reported as robustness |
| Moran's I (circulation) | 0.41, p < 0.001 | 0.08, p = 0.15 |
| Case ranking | Permatang Pauh and FELDA highest | no significant difference across cases (p = 0.25); Permatang Pauh lowest |
| GWR gradient, East/West difference | reported | GWR not estimated (approximate coordinates); no East/West difference (p = 0.62, 0.27) |
| Theoretical contribution "J varies with institutions" | central claim | removed; RQ3 reported as not supported, with power caveat |
| Non-response permutation test | reported | removed (the kampung counts used did not match the data) |
| Religious variable | "religious office holding", mean 0.046 | religious belief, mean 0.149, as coded in the data |
| Health | 3-point ordinal, mean 2.016 | binary, 1 = healthy, mean 0.667, as coded in the data |
| Age | linear, no note | top-coded at 70 (25 heads); robustness to age bands and exclusion in Table S3 panel B |

## Figures

| v13 | v14 |
|---|---|
| 1 Conceptual framework | Redrawn to match Section 2 (Figure 1) |
| 2 Location map | Rebuilt from Natural Earth boundaries with a key map (Figure 2) |
| 3 GIS workflow | Removed: described data and tools not used |
| 4 Sample characteristics | Regenerated from data (Figure 3) |
| 5 Coefficient bars | Replaced by standardised effects with CIs (Figure 4) |
| 6 Predicted probability | Regenerated from the probit with bands (Figure 5) |
| 7 Site rates and GSI scatter | Replaced by case rates and case-specific slopes (Figure 6) |
| 8 Moran scatter and GWR surface | Removed: not reproducible from data |
| 9 Policy scoring | Removed: subjective scores and unsupported effect sizes |

## Reviewer points where the data limit the response

- **R2, IV strategy:** no credible instrument in the data; stated as a limitation.
- **R3, spatial patterns of GSI/LSI and East/West contrast:** reported (Moran's I for all three variables; East interaction and case slopes). No differences found.
- **R1-13, sampling detail:** households were recruited toward approximate case targets by availability (4-15 per kampung); 420 targeted, 369 interviewed (87.9 per cent) after repeat visits; attempt-level records were not fully retained, so the v13 kampung-level non-response test is withdrawn and possible response bias is stated as a limitation.
- **R3, GSI/LSI construction:** both described as continuous indices of reported attitudes (village level and close network); limitations from perception-based, same-respondent measurement stated in Sections 3.6 and 6.
