# Data provenance

This file records the source of the household data and how it was collected and coded.

## Source

`data/households.csv` is the `LA_rights_rural_survey` sheet of the project workbook `MY_landuse_rights_rural_malaysia.xlsx` (checksum in `data/SOURCE_SHA256.txt`), with household coordinates removed. The workbook's other sheets (summary tables, an IV estimate, a regional interaction model, a respondent-profile table) are not used. They do not reproduce from the household data and are not part of this repository.

## Known properties

- 369 households in 7 cases (52-53 per case) and 42 kampungs (6 per case; 4-15 households per kampung).
- GSI is missing for 26 households and LSI for 24; all other variables are complete.
- Coordinates in the source workbook are approximate. They were recorded during the pilot, according to the project leader. They are used only as kampung-level means for Moran's I and as case-level markers in Figure 2.

## Fieldwork and coding

- Cases and mukims were selected purposively. Within kampungs, households were recruited toward an approximate case target according to availability, not by a fixed draw per kampung.
- Fieldwork targeted 420 households (60 per case); 369 were interviewed (87.9 per cent). Many households were hesitant to take part, and enumerators revisited some localities three or four times. Attempt-level records were not fully retained, so non-response cannot be analysed by kampung or household characteristics.
- Instruments were drafted and administered in Bahasa Malaysia; over 95 per cent of interviews were conducted in Malay. In cases 5 to 7, bilingual enumerators gave oral translation into Iban and Kadazandusun where needed. English versions were prepared after fieldwork for reporting only.
- Respondents who could not state their exact age were recorded as 70 (25 heads); age is top-coded.

## Data-quality checks

`qa/data_diagnostics.py` reports design consistency, pile-ups of values at hard bounds, correlations among household attributes, and between-case and between-kampung variation. For the current file it reports:

- clustering of values exactly at the bounds of age (21 and 70) and wealth (1.00);
- near-zero correlations among age, education, wealth and family size;
- no detectable differences across the seven tenure settings, or across kampungs beyond chance, for most variables.

Ages recorded as 70 reflect the top-coding described above.

## Not included

`landuse_rights_rural_malaysia.gms` is not part of this repository. That GAMS file generates variables by random draws rather than reading survey data, so it is not analysis code for the manuscript.
