"""Reproduce every table, figure and number in the manuscript.

    python run_all.py

Outputs:
    outputs/results.json   every number quoted in the manuscript
    outputs/tables/*.csv   Tables 2-4 and Supplementary Tables S2-S6
    outputs/figures/*.png  Figures 2-6 (Figure 1 is a schematic, see rlur/figures.py)
"""
import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

from rlur import data as D
from rlur import models as M
from rlur import figures as F

warnings.filterwarnings("ignore")
OUT = Path(__file__).resolve().parent / "outputs"
TAB = OUT / "tables"
TAB.mkdir(parents=True, exist_ok=True)
BINARY = {"married", "relig", "health", "occ2", "occ3", "split", "lmrc"}
CONT = ["age", "educ", "cityyr", "fam", "wealth", "area", "GSIs", "LSI"]
ALL = ["GSIs", "LSI"] + D.CONTROLS


def stars(p):
    return "***" if p < 0.01 else "**" if p < 0.05 else "*" if p < 0.10 else ""


def coef_table(models, names, path):
    rows = []
    for k in names:
        row = {"variable": D.SHORT.get(k, k)}
        for col, m in models.items():
            if k in m.params.index:
                row[col] = f"{m.params[k]:.4f}{stars(m.pvalues[k])} ({m.bse[k]:.4f})"
            else:
                row[col] = ""
        rows.append(row)
    for lab, fn in [("Case fixed effects", lambda m: "Yes"),
                    ("Observations", lambda m: str(int(m.nobs))),
                    ("Kampung clusters", lambda m: str(m.model.data.frame["kampung_id"].nunique())),
                    ("R\u00b2", lambda m: f"{m.rsquared:.3f}")]:
        rows.append({"variable": lab, **{c: fn(m) for c, m in models.items()}})
    pd.DataFrame(rows).to_csv(path, index=False)


def main():
    df = D.load()
    R = {"n_households": len(df), "n_kampungs": int(df.kampung_id.nunique()),
         "n_cases": int(df.case.nunique())}

    # ---------------- descriptives (Table 2) ------------------------------------
    desc = []
    for v in ["Y", "GSIs", "LSI"] + [c for c in D.CONTROLS if c not in ("occ2", "occ3")] + ["avgexp", "closeexp"]:
        s = df[v].dropna()
        desc.append(dict(variable=D.LABELS[v], key=v, N=len(s), mean=s.mean(), sd=s.std(),
                         min=s.min(), max=s.max()))
    desc = pd.DataFrame(desc)
    desc.round(3).to_csv(TAB / "table2_descriptives.csv", index=False)
    R["desc"] = {r.key: dict(N=int(r.N), mean=float(r["mean"]), sd=float(r.sd),
                             min=float(r["min"]), max=float(r["max"])) for _, r in desc.iterrows()}
    occ = df.occupation_category.value_counts().sort_index()
    R["occupation"] = {int(k): int(v) for k, v in occ.items()}
    R["case_n"] = {int(k): int(v) for k, v in df.case.value_counts().sort_index().items()}
    kn = df.kampung_id.value_counts()
    R["kampung_n"] = dict(min=int(kn.min()), max=int(kn.max()), median=float(kn.median()),
                          over10=int((kn > 10).sum()))
    R["missing"] = dict(GSI=int(df.GSI.isna().sum()), LSI=int(df.LSI.isna().sum()),
                        both=int((df.GSI.isna() & df.LSI.isna()).sum()))
    R["corr_gsi_lsi"] = float(df[["GSIs", "LSI"]].corr().iloc[0, 1])
    R["corr_gsi_avgexp"] = float(df[["GSIs", "avgexp"]].corr().iloc[0, 1])
    R["corr_lsi_closeexp"] = float(df[["LSI", "closeexp"]].corr().iloc[0, 1])

    # ---------------- main models (Table 3) -------------------------------------
    mG = M.lpm(df, ["GSIs"]); mL = M.lpm(df, ["LSI"])
    mJ = M.lpm(df, ["GSIs", "LSI"])
    coef_table({"(1) Global": mG, "(2) Local": mL, "(3) Joint": mJ}, ALL,
               TAB / "table3_main_lpm.csv")
    R["main"] = {}
    for name, m in [("G", mG), ("L", mL), ("J", mJ)]:
        R["main"][name] = dict(fit=M.fit_stats(m), coef=M.tidy(m, ALL),
                               std=M.standardised(m, df, [k for k in ALL if k in m.params], BINARY))
        R["main"][name]["ybar"] = float(m.model.data.frame["Y"].mean())
    # Do the channels differ on the standardised scale? (joint model)
    sdG = float(mJ.model.data.frame["GSIs"].std()); sdL = float(mJ.model.data.frame["LSI"].std())
    wt = mJ.wald_test(f"{sdG} * GSIs - {sdL} * LSI = 0", scalar=True)
    R["std_diff"] = dict(diff=float(mJ.params["GSIs"] * sdG - mJ.params["LSI"] * sdL),
                         F=float(wt.statistic), p=float(wt.pvalue))
    # VIFs in joint model
    from statsmodels.stats.outliers_influence import variance_inflation_factor as vif
    X = mJ.model.exog; names = mJ.model.exog_names
    R["vif"] = {n: float(vif(X, i)) for i, n in enumerate(names) if n in ("GSIs", "LSI")}

    # ---------------- robustness (Table 4 / S3) ----------------------------------
    w = M.winsorise(df, CONT)
    mWG = M.lpm(w, ["GSIs"]); mWL = M.lpm(w, ["LSI"])
    mAG = M.lpm(df, ["avgexp"], need=["GSIs"]); mAL = M.lpm(df, ["closeexp"], need=["LSI"])
    mAG_full = M.lpm(df, ["avgexp"], need=["avgexp"]); mAL_full = M.lpm(df, ["closeexp"], need=["closeexp"])
    pG = M.probit(df, ["GSIs"]); pL = M.probit(df, ["LSI"])
    R["robust"] = dict(
        wins_G=M.tidy(mWG, ["GSIs"])["GSIs"], wins_L=M.tidy(mWL, ["LSI"])["LSI"],
        lik_G=M.tidy(mAG, ["avgexp"])["avgexp"], lik_L=M.tidy(mAL, ["closeexp"])["closeexp"],
        lik_G_full=M.tidy(mAG_full, ["avgexp"])["avgexp"] | {"n": int(mAG_full.nobs)},
        lik_L_full=M.tidy(mAL_full, ["closeexp"])["closeexp"] | {"n": int(mAL_full.nobs)},
        lik_G_std=M.standardised(mAG, df, ["avgexp"], set())["avgexp"],
        lik_L_std=M.standardised(mAL, df, ["closeexp"], set())["closeexp"],
        probit_G=M.probit_summary(pG, "GSIs"), probit_L=M.probit_summary(pL, "LSI"),
        n=dict(wins_G=int(mWG.nobs), wins_L=int(mWL.nobs), lik_G=int(mAG.nobs), lik_L=int(mAL.nobs)),
        r2=dict(wins_G=mWG.rsquared, wins_L=mWL.rsquared, lik_G=mAG.rsquared, lik_L=mAL.rsquared))
    # Table 4: compact robustness table
    rows = []
    def add(label, t, n, extra=""):
        rows.append(dict(specification=label, coefficient=f"{t['b']:.4f}{stars(t['p'])}",
                         se=f"({t['se']:.4f})", p=f"{t['p']:.3f}", N=n, note=extra))
    add("Baseline LPM, GSI*", R["main"]["G"]["coef"]["GSIs"], mG.nobs)
    add("Winsorised (1st/99th), GSI*", R["robust"]["wins_G"], mWG.nobs)
    add("Likert substitute: village-wide expectation (1-7)", R["robust"]["lik_G"], mAG.nobs)
    pg = R["robust"]["probit_G"]
    add("Probit, GSI* (average marginal effect)", dict(b=pg["ame"], se=pg["ame_se"], p=pg["ame_p"]), pg["n"],
        f"index coef {pg['b']:.3f}; pseudo-R2 {pg['pseudo_r2']:.3f}")
    add("Baseline LPM, LSI", R["main"]["L"]["coef"]["LSI"], mL.nobs)
    add("Winsorised (1st/99th), LSI", R["robust"]["wins_L"], mWL.nobs)
    add("Likert substitute: close-group expectation (1-7)", R["robust"]["lik_L"], mAL.nobs)
    pl = R["robust"]["probit_L"]
    add("Probit, LSI (average marginal effect)", dict(b=pl["ame"], se=pl["ame_se"], p=pl["ame_p"]), pl["n"],
        f"index coef {pl['b']:.3f}; pseudo-R2 {pl['pseudo_r2']:.3f}")
    pd.DataFrame(rows).to_csv(TAB / "table4_robustness.csv", index=False)
    coef_table({"Wins. GSI*": mWG, "Wins. LSI": mWL, "Likert village": mAG, "Likert close": mAL},
               ["GSIs", "LSI", "avgexp", "closeexp"] + D.CONTROLS, TAB / "tableS3_robustness_full.csv")

    # ---------------- age top-coding (Supplementary Table S3, panel B) -------------
    import statsmodels.formula.api as smf
    df["age70"] = (df["age"] == 70).astype(int)
    df["ageband"] = pd.cut(df["age"], [0, 34, 44, 54, 64, 69, 70],
                           labels=["lt35", "35_44", "45_54", "55_64", "65_69", "70approx"])
    ctrl = " + ".join(D.CONTROLS) + " + C(case)"
    ctrl_noage = ctrl.replace("age + ", "")
    def cl(formula, d):
        return smf.ols(formula, d).fit(cov_type="cluster", cov_kwds={"groups": d["kampung_id"]}, use_t=True)
    R["age70"] = dict(n=int(df.age70.sum()), share=float(df.age70.mean()),
                      rate=float(df[df.age70 == 1].Y.mean()), rate_other=float(df[df.age70 == 0].Y.mean()))
    R["age_robust"] = {}
    for v in ["GSIs", "LSI"]:
        d = df.dropna(subset=[v])
        specs = {"indicator": cl(f"Y ~ {v} + {ctrl} + age70", d),
                 "bands": cl(f"Y ~ {v} + {ctrl_noage} + C(ageband)", d),
                 "exclude": cl(f"Y ~ {v} + {ctrl}", d[d.age70 == 0])}
        R["age_robust"][v] = {k: dict(**M.tidy(m, [v])[v], n=int(m.nobs)) for k, m in specs.items()}
        if v == "GSIs":
            bm = specs["bands"]
            R["age_bands"] = {k.split("T.")[1].rstrip("]"): dict(b=float(bm.params[k]), p=float(bm.pvalues[k]))
                              for k in bm.params.index if "ageband" in k}
    df = df.drop(columns=["age70", "ageband"])

    # ---------------- heterogeneity by tenure setting (Table 5 / S5) -------------
    R["hetero"] = {}
    for v in ["GSIs", "LSI"]:
        mE, tE = M.east_interaction(df, v)
        mC, tC, wald = M.case_slopes(df, v)
        R["hetero"][v] = dict(east=tE, east_n=int(mE.nobs),
                              case={int(k.split("_c")[1]): t for k, t in tC.items()},
                              wald=wald)
    rows = []
    for c in range(1, 8):
        rows.append(dict(case=c, site=D.CASES[c],
                         gsi_slope=f"{R['hetero']['GSIs']['case'][c]['b']:.3f} ({R['hetero']['GSIs']['case'][c]['se']:.3f})",
                         lsi_slope=f"{R['hetero']['LSI']['case'][c]['b']:.3f} ({R['hetero']['LSI']['case'][c]['se']:.3f})"))
    pd.DataFrame(rows).to_csv(TAB / "tableS5_case_slopes.csv", index=False)

    # minimum detectable interaction (two-sided 5%, 80% power), t with 41 df
    from scipy import stats as st
    mult = st.t.ppf(0.975, 41) + st.t.ppf(0.80, 41)
    for v in ["GSIs", "LSI"]:
        se = R["hetero"][v]["east"][f"{v}:east"]["se"]
        R["hetero"][v]["mde_east"] = float(mult * se)

    # ---------------- between-case and between-kampung structure -----------------
    cd = M.case_differences(df)
    R["cases"] = cd
    R["icc"] = {v: M.icc_anova(df, v, "kampung_id") for v in ["Y", "GSIs", "LSI"]}
    R["case_means"] = {int(c): dict(GSIs=float(g.GSIs.mean()), LSI=float(g.LSI.mean()))
                       for c, g in df.groupby("case")}
    kmp = df.groupby("kampung_id").agg(Y=("Y", "mean"), GSIs=("GSIs", "mean"), LSI=("LSI", "mean"))
    kc = D.kampungs().set_index("kampung_id").loc[kmp.index]
    coords = kc[["lat", "lon"]].to_numpy()
    R["moran"] = {}
    for v in ["Y", "GSIs", "LSI"]:
        res, W = M.morans_i(kmp[v].to_numpy(), coords)
        R["moran"][v] = res
    pd.DataFrame([dict(variable=v, **R["moran"][v]) for v in R["moran"]]).to_csv(
        TAB / "tableS6_morans_i.csv", index=False)
    pd.DataFrame([dict(case=c, site=D.CASES[c], **cd["rates"][c]) for c in cd["rates"]]).to_csv(
        TAB / "tableS2_case_rates.csv", index=False)
    ks = df.groupby(["case", "kampung_id"]).size().rename("households").reset_index()
    ks.to_csv(TAB / "tableS2_kampung_counts.csv", index=False)

    # ---------------- figures ----------------------------------------------------
    grid_g = np.linspace(df.GSIs.min(), df.GSIs.max(), 60)
    grid_l = np.linspace(0, 1, 60)
    curves = dict(G=(grid_g, *M.predicted_curve(pG, "GSIs", grid_g)),
                  L=(grid_l, *M.predicted_curve(pL, "LSI", grid_l)))
    F.fig1_framework()
    F.fig2_location(df)
    F.fig3_sample(df, R)
    F.fig4_effects(R)
    F.fig5_predicted(df, curves)
    F.fig6_cases(R)

    with open(OUT / "results.json", "w") as f:
        json.dump(R, f, indent=1, default=float)
    print("Done. Key results:")
    for n, k in [("G", "GSIs"), ("L", "LSI")]:
        c = R["main"][n]["coef"][k]; s = R["main"][n]["std"][k]
        print(f"  {k}: b={c['b']:.3f} se={c['se']:.3f} p={c['p']:.4f}; 1 SD = {100*s['eff']:.1f} pp; "
              f"N={R['main'][n]['fit']['n']} R2={R['main'][n]['fit']['r2']:.3f}")


if __name__ == "__main__":
    main()
