# Codebook: data/households.csv

| Column | Analysis name | Definition | Coding |
|---|---|---|---|
| survey_id | | Household identifier | 1-369 |
| city_fe | case | Case (site) | 1 FELDA Serting Hilir; 2 Baling; 3 Permatang Pauh; 4 Mersing; 5 Ranau; 6 Kg. Sinulihan; 7 Kapit |
| city_name | | Case name and state | text |
| region_fe, region_name | | Region code in source file | not used in analysis |
| kampung_id | | Kampung identifier (clustering unit) | 1-42, six per case |
| circulation_DV | Y | Household has circulated, has decided to circulate, or is likely to circulate the residential land use right | 1 yes, 0 no |
| global_social_interaction_GSI | GSI (GSI\* = 2 x GSI) | Perceived pro-circulation attitude of the village population | continuous, source scale [0, 0.5]; 26 missing |
| local_social_interaction_LSI | LSI | Perceived pro-circulation attitude of close kin, friends and neighbours | continuous [0, 1]; 24 missing |
| age | age | Age of household head | years |
| educational_background | educ | Years of formal schooling | years |
| marriage_status | married | Currently married | 1 yes, 0 no |
| religious_belief | relig | Religious belief | 1 yes, 0 no |
| self_evaluated_health | health | Self-evaluated health | 1 healthy, 0 not healthy or unsure |
| city_living_period_yr | cityyr | Years lived in an urban area | years |
| occupation_category | occ2, occ3 | Occupation of head | 1 farming (reference), 2 mixed livelihood, 3 non-farm |
| family_scale | fam | Household members | count |
| household_splitting_son | split | Household splitting for a son required | 1 yes, 0 no |
| family_net_wealth_MYR10k | wealth | Net financial assets | MYR 10,000 |
| homestead_area_m2 | area | Building plus courtyard area | m² |
| land_mgmt_right_circulation | lmrc | Agricultural land management right has been, will be, or is likely to be circulated | 1 yes, 0 no |
| likert_overall_avg_expectation | avgexp | Expectation of village-wide circulation | Likert 1-7 |
| likert_closegroup_expectation | closeexp | Expectation of close-group circulation | Likert 1-7 |

## Notes

- **GSI and LSI.** Continuous indices of reported attitudes toward renting out residential home lots: GSI at village level, LSI within the household's close network (kin, friends, neighbours). Higher values indicate a more permissive reported environment. GSI is recorded on [0, 0.5] and rescaled in the analysis as GSI\* = 2 x GSI.
- **Age.** Respondents who could not state their exact age, mostly older heads, were recorded as 70 (25 heads). Age is therefore top-coded at 70.
- **Likert items.** `avgexp` and `closeexp` are seven-point expectation items used as alternative measures of the two channels.
