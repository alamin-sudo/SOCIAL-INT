// Keep only references cited in the text; report citations with no reference.
const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
function cited(ref, text) {
  return new RegExp(esc(ref.name) + "[^;)\\n]{0,40}?" + ref.year).test(text);
}
function buildRefs(REFS, text) {
  const used = REFS.filter(r => cited(r, text));
  const dropped = REFS.filter(r => !cited(r, text));
  console.log(`references used: ${used.length}; dropped (not cited): ${dropped.map(r => r.name + " " + r.year).join(", ") || "none"}`);
  const re = /([A-Z][A-Za-z\u00C0-\u017F'\u2019-]+)(?: and [A-Z][A-Za-z\u00C0-\u017F'\u2019 -]+?| et al\.)?(?:,| \()\s?(\d{4})/g;
  const miss = new Set(); let m;
  while ((m = re.exec(text)) !== null) {
    const [_, nm, yr] = m;
    if (["Figure", "Table", "Section", "January", "August", "Act", "Code", "Plan", "Budget", "Phase"].includes(nm)) continue;
    if (!REFS.some(r => r.text.includes(nm) && r.text.includes(yr))) miss.add(nm + " " + yr);
  }
  console.log(`citations with no reference: ${[...miss].join(", ") || "none"}`);
  return used.map(r => r.text);
}
module.exports = { buildRefs, cited };
