// Shared helpers for building the manuscript and supplement (docx-js).
const fs = require("fs");
const path = require("path");
const D = require("docx");
const { Paragraph, TextRun, ImageRun, Table, TableRow, TableCell, WidthType, AlignmentType,
  BorderStyle, HeadingLevel, ShadingType, VerticalAlign } = D;

const FONT = "Times New Roman";
const TEXT_W = 9026; // A4 with 1" margins, DXA

// Inline markup: **bold**, *italic*, ⟦note⟧ (yellow highlight), _{sub}, ^{sup}
function runs(text, base = {}) {
  text = String(text).replace(/\\\*/g, "\u0001");   // "\*" = literal asterisk
  const T = (s) => s.replace(/\u0001/g, "*");
  const out = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|⟦[^⟧]+⟧|_\{[^}]+\}|\^\{[^}]+\})/g;
  let last = 0, m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(new TextRun({ text: T(text.slice(last, m.index)), font: FONT, ...base }));
    const t = m[0];
    if (t.startsWith("**")) out.push(...runs(t.slice(2, -2), { ...base, bold: true }));
    else if (t.startsWith("⟦")) out.push(new TextRun({ text: T(t), font: FONT, ...base, highlight: "yellow", bold: true }));
    else if (t.startsWith("_{")) out.push(new TextRun({ text: T(t.slice(2, -1)), font: FONT, ...base, subScript: true }));
    else if (t.startsWith("^{")) out.push(new TextRun({ text: T(t.slice(2, -1)), font: FONT, ...base, superScript: true }));
    else out.push(...runs(t.slice(1, -1), { ...base, italics: true }));
    last = m.index + t.length;
  }
  if (last < text.length) out.push(new TextRun({ text: T(text.slice(last)), font: FONT, ...base }));
  return out;
}

const p = (text, opt = {}) => new Paragraph({
  children: runs(text, opt.run || {}), alignment: opt.align || AlignmentType.JUSTIFIED,
  spacing: { after: opt.after ?? 160, line: opt.line ?? 360 }, indent: opt.indent,
  keepNext: opt.keepNext,
});
const h1 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_1, children: runs(t), spacing: { before: 280, after: 160 } });
const h2 = (t) => new Paragraph({ heading: HeadingLevel.HEADING_2, children: runs(t), spacing: { before: 220, after: 120 } });
const eq = (text, num) => new Paragraph({
  children: [...runs(text), new TextRun({ text: `\t(${num})`, font: FONT })],
  tabStops: [{ type: D.TabStopType.RIGHT, position: TEXT_W }], alignment: AlignmentType.CENTER,
  spacing: { before: 80, after: 160, line: 300 },
});
const caption = (text) => new Paragraph({ children: runs(text, { size: 22 }), spacing: { before: 80, after: 240, line: 276 }, alignment: AlignmentType.LEFT });
const note = (text) => new Paragraph({ children: runs(text, { size: 18, italics: false }), spacing: { before: 60, after: 240, line: 240 }, alignment: AlignmentType.LEFT });
const tableTitle = (text) => new Paragraph({ children: runs(text, { size: 22 }), spacing: { before: 200, after: 80, line: 276 }, keepNext: true });

function pngSize(file) {
  const b = fs.readFileSync(file);
  return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
}
function figure(file, widthIn = 6.2) {
  const { w, h } = pngSize(file);
  const W = widthIn * 96, H = W * h / w;
  return new Paragraph({
    alignment: AlignmentType.CENTER, spacing: { before: 120, after: 60 }, keepNext: true,
    children: [new ImageRun({ type: "png", data: fs.readFileSync(file), transformation: { width: W, height: H },
      altText: { title: path.basename(file), description: path.basename(file), name: path.basename(file) } })],
  });
}

const thin = { style: BorderStyle.SINGLE, size: 4, color: "000000" };
const none = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
// Journal-style table: rules above header, below header, and at the bottom only.
function table(header, rows, widths, opt = {}) {
  const total = widths.reduce((a, b) => a + b, 0);
  const sz = opt.size || 18;
  const mk = (cells, i, isHead) => new TableRow({
    tableHeader: isHead,
    children: cells.map((c, j) => new TableCell({
      width: { size: widths[j], type: WidthType.DXA },
      verticalAlign: VerticalAlign.CENTER,
      margins: { top: 40, bottom: 40, left: 80, right: 80 },
      borders: {
        top: isHead ? thin : none, left: none, right: none,
        bottom: isHead ? thin : (i === rows.length - 1 ? thin : none),
      },
      shading: opt.shadeRows && opt.shadeRows.includes(i) && !isHead ? { type: ShadingType.CLEAR, fill: "F2F2F2", color: "auto" } : undefined,
      children: [new Paragraph({
        alignment: j === 0 ? AlignmentType.LEFT : (opt.alignLeft ? AlignmentType.LEFT : AlignmentType.CENTER),
        spacing: { after: 0, line: 240 },
        children: runs(String(c), { size: sz, bold: isHead || undefined }),
      })],
    })),
  });
  return new Table({
    width: { size: total, type: WidthType.DXA }, columnWidths: widths,
    rows: [mk(header, -1, true), ...rows.map((r, i) => mk(r, i, false))],
  });
}

// Number formatting
const f = (x, d = 3) => (x < 0 ? "\u2212" : "") + Math.abs(x).toFixed(d);
const pp = (x, d = 1) => (x < 0 ? "\u2212" : "") + Math.abs(100 * x).toFixed(d);
const pv = (x) => (x < 0.001 ? "< 0.001" : "= " + x.toFixed(3));
const star = (p) => (p < 0.01 ? "\\*\\*\\*" : p < 0.05 ? "\\*\\*" : p < 0.1 ? "\\*" : "");

function styles() {
  return {
    default: { document: { run: { font: FONT, size: 24 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, font: FONT }, paragraph: { spacing: { before: 280, after: 160 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 24, bold: true, italics: true, font: FONT }, paragraph: { spacing: { before: 220, after: 120 }, outlineLevel: 1 } },
    ],
  };
}
function section(children, opt = {}) {
  return {
    properties: {
      page: { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } },
      lineNumbers: opt.lineNumbers ? { countBy: 1, restart: D.LineNumberRestartFormat.CONTINUOUS } : undefined,
    },
    footers: { default: new D.Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: [D.PageNumber.CURRENT], font: FONT, size: 20 })] })] }) },
    children,
  };
}
async function save(doc, file) {
  fs.writeFileSync(file, await D.Packer.toBuffer(doc));
  console.log("wrote", file);
}
module.exports = { D, runs, p, h1, h2, eq, caption, note, tableTitle, figure, table, f, pp, pv, star, styles, section, save, TEXT_W };
