module.exports = [
 {
  "name": "Adu",
  "year": "2024",
  "text": "Adu, P., Miles, D.A., 2024. Dissertation Research Methods: A Step by Step Guide to Writing Up Your Research in the Social Sciences. Routledge, New York."
 },
 {
  "name": "A’Hearn",
  "year": "2009",
  "text": "A’Hearn, B., Baten, J., Crayen, D., 2009. Quantifying quantitative literacy: Age heaping and the history of human capital. Journal of Economic History 69(3), 783–808."
 },
 {
  "name": "Ajzen",
  "year": "1991",
  "text": "Ajzen, I., 1991. The theory of planned behavior. Organizational Behavior and Human Decision Processes 50(2), 179–211."
 },
 {
  "name": "Alchian",
  "year": "1972",
  "text": "Alchian, A.A., Demsetz, H., 1972. Production, information costs, and economic organization. American Economic Review 62(5), 777–795."
 },
 {
  "name": "Anselin",
  "year": "1995",
  "text": "Anselin, L., 1995. Local indicators of spatial association, LISA. Geographical Analysis 27(2), 93–115."
 },
 {
  "name": "Azima",
  "year": "2024",
  "text": "Azima, A.M., Dimbab, N., Affandi, H.M., Anuar, A., Mohamed, R., 2024. Communal grant and land allocation effect on native customary land disputation in Sarawak, Malaysia. Land Use Policy 139, 107066."
 },
 {
  "name": "Aziz",
  "year": "2012",
  "text": "Aziz, N.N.A., Hassan, W.H.A.W., Saud, N.A., 2012. The effects of urbanization towards social and cultural changes among Malaysian settlers in FELDA, Johor. Procedia, Social and Behavioural Sciences 68, 910–920."
 },
 {
  "name": "Babbie",
  "year": "2021",
  "text": "Babbie, E.R., 2021. The Practice of Social Research, 15th ed. Cengage Learning, Boston."
 },
 {
  "name": "Banerjee",
  "year": "2013",
  "text": "Banerjee, A., Chandrasekhar, A.G., Duflo, E., Jackson, M.O., 2013. The diffusion of microfinance. Science 341(6144), 1236498."
 },
 {
  "name": "Barau",
  "year": "2016",
  "text": "Barau, A.S., Said, I., 2016. From goodwill to good deals: FELDA land resettlement scheme and the ascendancy of the landless poor in Malaysia. Land Use Policy 54, 423–431."
 },
 {
  "name": "Barzel",
  "year": "1997",
  "text": "Barzel, Y., 1997. Economic Analysis of Property Rights, 2nd ed. Cambridge University Press, Cambridge."
 },
 {
  "name": "Becker",
  "year": "1991",
  "text": "Becker, G.S., 1991. A note on restaurant pricing and other examples of social influences on price. Journal of Political Economy 99(5), 1109–1116."
 },
 {
  "name": "Bernheim",
  "year": "1994",
  "text": "Bernheim, B.D., 1994. A theory of conformity. Journal of Political Economy 102(5), 841–877."
 },
 {
  "name": "Bhattacherjee",
  "year": "2012",
  "text": "Bhattacherjee, A., 2012. Social Science Research: Principles, Methods, and Practices, 2nd ed. University of South Florida, Tampa."
 },
 {
  "name": "Bikhchandani",
  "year": "1992",
  "text": "Bikhchandani, S., Hirshleifer, D., Welch, I., 1992. A theory of fads, fashion, custom, and cultural change as informational cascades. Journal of Political Economy 100(5), 992–1026."
 },
 {
  "name": "Bingham",
  "year": "2023",
  "text": "Bingham, A.J., Mitchell, R., Carter, D.J., 2023. Qualitative Analysis: Deductive and Inductive Approaches. Routledge, New York."
 },
 {
  "name": "Blume",
  "year": "2011",
  "text": "Blume, L.E., Brock, W.A., Durlauf, S.N., Ioannides, Y.M., 2011. Identification of social interactions. In: Benhabib, J., Bisin, A., Jackson, M.O. (Eds.), Handbook of Social Economics, Vol. 1B. North Holland, Amsterdam, 853–964."
 },
 {
  "name": "Bramoullé",
  "year": "2009",
  "text": "Bramoullé, Y., Djebbari, H., Fortin, B., 2009. Identification of peer effects through social networks. Journal of Econometrics 150(1), 41–55."
 },
 {
  "name": "Brock",
  "year": "2001",
  "text": "Brock, W.A., Durlauf, S.N., 2001. Discrete choice with social interactions. Review of Economic Studies 68(2), 235–260."
 },
 {
  "name": "Buang",
  "year": "2007",
  "text": "Buang, S., 2007. Malaysian Torrens System, 2nd ed. Dewan Bahasa dan Pustaka, Kuala Lumpur."
 },
 {
  "name": "Buang",
  "year": "2013",
  "text": "Buang, S., 2013. Land Tenure in Peninsular Malaysia: Prospects for Reform. Institute of Strategic and International Studies, Kuala Lumpur."
 },
 {
  "name": "Carsten",
  "year": "1997",
  "text": "Carsten, J., 1997. The Heat of the Hearth: The Process of Kinship in a Malay Fishing Community. Clarendon Press, Oxford."
 },
 {
  "name": "Coleman",
  "year": "1988",
  "text": "Coleman, J.S., 1988. Social capital in the creation of human capital. American Journal of Sociology 94, S95–S120."
 },
 {
  "name": "De Soto",
  "year": "2000",
  "text": "De Soto, H., 2000. The Mystery of Capital: Why Capitalism Triumphs in the West and Fails Everywhere Else. Basic Books, New York."
 },
 {
  "name": "Demsetz",
  "year": "1967",
  "text": "Demsetz, H., 1967. Toward a theory of property rights. American Economic Review 57(2), 347–359."
 },
 {
  "name": "DOSM",
  "year": "2020",
  "text": "Department of Statistics Malaysia (DOSM), 2020. Household Income and Basic Amenities Survey Report 2019. DOSM, Putrajaya."
 },
 {
  "name": "DOSM",
  "year": "2023",
  "text": "Department of Statistics Malaysia (DOSM), 2023. Malaysian Economic Statistics: Urbanisation and Demographic Trends 1970–2020. DOSM, Putrajaya."
 },
 {
  "name": "DOSM",
  "year": "2024",
  "text": "Department of Statistics Malaysia (DOSM), 2024. Household Income Survey Report 2024. DOSM, Putrajaya."
 },
 {
  "name": "Durlauf",
  "year": "2010",
  "text": "Durlauf, S.N., Ioannides, Y.M., 2010. Social interactions. Annual Review of Economics 2, 451–478."
 },
 {
  "name": "Economic Planning Unit",
  "year": "2021",
  "text": "Economic Planning Unit, 2021. Twelfth Malaysia Plan 2021–2025. Prime Minister’s Department, Putrajaya."
 },
 {
  "name": "Ellison",
  "year": "1993",
  "text": "Ellison, G., Fudenberg, D., 1993. Rules of thumb for social learning. Journal of Political Economy 101(4), 612–643."
 },
 {
  "name": "Fotheringham",
  "year": "2002",
  "text": "Fotheringham, A.S., Brunsdon, C., Charlton, M., 2002. Geographically Weighted Regression: The Analysis of Spatially Varying Relationships. Wiley, Chichester."
 },
 {
  "name": "Gerring",
  "year": "2017",
  "text": "Gerring, J., 2017. Case Study Research: Principles and Practices, 2nd ed. Cambridge University Press, Cambridge."
 },
 {
  "name": "Goodchild",
  "year": "2007",
  "text": "Goodchild, M.F., 2007. Citizens as sensors: The world of volunteered geography. GeoJournal 69(4), 211–221."
 },
 {
  "name": "Government of Malaysia",
  "year": "2025",
  "text": "Government of Malaysia, 2025. Thirteenth Malaysia Plan 2026–2030. Economic Planning Unit, Prime Minister’s Department, Putrajaya."
 },
 {
  "name": "Granovetter",
  "year": "1985",
  "text": "Granovetter, M., 1985. Economic action and social structure: The problem of embeddedness. American Journal of Sociology 91(3), 481–510."
 },
 {
  "name": "SUHAKAM",
  "year": "2013",
  "text": "Human Rights Commission of Malaysia (SUHAKAM), 2013. Report of the National Inquiry into the Land Rights of Indigenous Peoples. SUHAKAM, Kuala Lumpur."
 },
 {
  "name": "JUPEM",
  "year": "2022",
  "text": "JUPEM (Department of Survey and Mapping Malaysia), 2022. National Digital Cadastral Database (NDCDB): Implementation Status and Pekeliling Ketua Pengarah Ukur. JUPEM, Kuala Lumpur."
 },
 {
  "name": "Kish",
  "year": "1965",
  "text": "Kish, L., 1965. Survey Sampling. John Wiley and Sons, New York."
 },
 {
  "name": "Krupka",
  "year": "2013",
  "text": "Krupka, E.L., Weber, R.A., 2013. Identifying social norms using coordination games: Why does dictator game sharing vary? Journal of the European Economic Association 11(3), 495–524."
 },
 {
  "name": "Land (Group Settlement Areas) Act",
  "year": "1960",
  "text": "Land (Group Settlement Areas) Act 1960 (Act 530). Laws of Malaysia, Kuala Lumpur."
 },
 {
  "name": "Liang",
  "year": "2015",
  "text": "Liang, P., Guo, S., 2015. Social interaction, internet access and stock market participation: An empirical study in China. Journal of Comparative Economics 43(4), 883–901."
 },
 {
  "name": "Libecap",
  "year": "1989",
  "text": "Libecap, G.D., 1989. Contracting for Property Rights. Cambridge University Press, Cambridge."
 },
 {
  "name": "Ling",
  "year": "2019",
  "text": "Ling, G.H.T., Leng, P.C., Ho, C.S., 2019. Effects of diverse property rights on rural neighbourhood public open space governance: Evidence from Sabah, Malaysia. Economies 7(2), 1–33."
 },
 {
  "name": "Maidin",
  "year": "2022",
  "text": "Maidin, A.J., Syed Abdul Kader, S.Z., 2022. Principles of Malaysian Land Law. LexisNexis, Kuala Lumpur."
 },
 {
  "name": "Manski",
  "year": "1993",
  "text": "Manski, C.F., 1993. Identification of endogenous social effects: The reflection problem. Review of Economic Studies 60(3), 531–542."
 },
 {
  "name": "Mansuri",
  "year": "2013",
  "text": "Mansuri, G., Rao, V., 2013. Localizing Development: Does Participation Work? World Bank, Washington, DC."
 },
 {
  "name": "Md Rami",
  "year": "2022",
  "text": "Md Rami, A.A., Zaremohzzabieh, Z., Aziz, F., Ismail, I.A., Abdullah, H., 2022. Moderating role of extrinsic and intrinsic motivations in community leadership and social capital in rural Malaysia. Sustainability 14(24), 16375."
 },
 {
  "name": "Ministry of Agriculture and Food Industries",
  "year": "2024",
  "text": "Ministry of Agriculture and Food Industries, 2024. National Agrofood Policy 2.0: Addressing Idle Land and Food Security. MAFI, Putrajaya."
 },
 {
  "name": "Ministry of Economy",
  "year": "2024",
  "text": "Ministry of Economy, 2024. SDG Roadmap Phase II and Alignment with National Development Planning. Ministry of Economy, Putrajaya."
 },
 {
  "name": "Ministry of Finance",
  "year": "2024",
  "text": "Ministry of Finance, 2024. Belanjawan 2025. Ministry of Finance, Putrajaya."
 },
 {
  "name": "Ministry of Finance",
  "year": "2025",
  "text": "Ministry of Finance, 2025. Budget 2026 Speech (Belanjawan 2026). Ministry of Finance, Putrajaya."
 },
 {
  "name": "Moran",
  "year": "1950",
  "text": "Moran, P.A.P., 1950. Notes on continuous stochastic phenomena. Biometrika 37(1–2), 17–23."
 },
 {
  "name": "Musakwa",
  "year": "2015",
  "text": "Musakwa, W., Van Niekerk, A., 2015. Land use change implications for sustainability: An analysis using GIS and remote sensing. Urban, Planning and Transport Research 3(1), 1–18."
 },
 {
  "name": "National Land Code",
  "year": "1965",
  "text": "National Land Code, 1965. National Land Code (Act 56 of 1965). Laws of Malaysia, Kuala Lumpur."
 },
 {
  "name": "Ngidang",
  "year": "2002",
  "text": "Ngidang, D., 2002. Contradictions in land development schemes: The case of joint ventures in Sarawak, Malaysia. Asia Pacific Viewpoint 43(2), 157–180."
 },
 {
  "name": "North",
  "year": "1990",
  "text": "North, D.C., 1990. Institutions, Institutional Change and Economic Performance. Cambridge University Press, Cambridge."
 },
 {
  "name": "Ostrom",
  "year": "1990",
  "text": "Ostrom, E., 1990. Governing the Commons: The Evolution of Institutions for Collective Action. Cambridge University Press, Cambridge."
 },
 {
  "name": "Peletz",
  "year": "1988",
  "text": "Peletz, M.G., 1988. A Share of the Harvest: Kinship, Property, and Social History among the Malays of Rembau. University of California Press, Berkeley."
 },
 {
  "name": "PRB",
  "year": "2024",
  "text": "PRB, 2024. 2024 World Population Data Sheet. Population Reference Bureau, Washington, DC."
 },
 {
  "name": "Putnam",
  "year": "2000",
  "text": "Putnam, R.D., 2000. Bowling Alone: The Collapse and Revival of American Community. Simon and Schuster, New York."
 },
 {
  "name": "Ragin",
  "year": "1992",
  "text": "Ragin, C.C., Becker, H.S. (Eds.), 1992. What Is a Case? Exploring the Foundations of Social Inquiry. Cambridge University Press, Cambridge."
 },
 {
  "name": "Ravitch",
  "year": "2021",
  "text": "Ravitch, S.M., Carl, N.M., 2021. Qualitative Research: Bridging the Conceptual, Theoretical, and Methodological, 2nd ed. SAGE, Thousand Oaks, CA."
 },
 {
  "name": "Ravitch",
  "year": "2017",
  "text": "Ravitch, S.M., Riggan, M., 2017. Reason and Rigor: How Conceptual Frameworks Guide Research, 2nd ed. SAGE, Thousand Oaks, CA."
 },
 {
  "name": "Rogers",
  "year": "2003",
  "text": "Rogers, E.M., 2003. Diffusion of Innovations, 5th ed. Free Press, New York."
 },
 {
  "name": "Samat",
  "year": "2011",
  "text": "Samat, N., Hasni, R., Elhadary, Y.A.E., 2011. Modelling land use changes at the peri urban areas using GIS and cellular automata. Journal of Sustainable Development 4(6), 72–84."
 },
 {
  "name": "Scott",
  "year": "2014",
  "text": "Scott, W.R., 2014. Institutions and Organizations: Ideas, Interests, and Identities, 4th ed. SAGE, Thousand Oaks, CA."
 },
 {
  "name": "Siwar",
  "year": "2016",
  "text": "Siwar, C., Ahmed, F., Bashawir, A., Mia, M.S., 2016. Urbanization and urban poverty in Malaysia: Consequences and vulnerability. Journal of Applied Sciences 16(4), 154–160."
 },
 {
  "name": "Stake",
  "year": "2005",
  "text": "Stake, R.E., 2005. Qualitative case studies. In: Denzin, N.K., Lincoln, Y.S. (Eds.), The SAGE Handbook of Qualitative Research, 3rd ed. SAGE, Thousand Oaks, CA, 443–466."
 },
 {
  "name": "United Nations",
  "year": "2015",
  "text": "United Nations, 2015. Transforming Our World: The 2030 Agenda for Sustainable Development. United Nations, New York."
 },
 {
  "name": "Wang",
  "year": "2012",
  "text": "Wang, H., Wang, L., Su, F., Tao, R., 2012. Rural residential properties in China: Land use patterns, efficiency and prospects for reform. Habitat International 36(2), 201–209."
 },
 {
  "name": "Wang",
  "year": "2018",
  "text": "Wang, J., Zhang, W., Zhang, Z., 2018. Quantifying the spatio temporal dynamics of rural settlements and the associated impacts on land use in an undeveloped area of China. Sustainability 10(5), 1490."
 },
 {
  "name": "Williamson",
  "year": "1985",
  "text": "Williamson, O.E., 1985. The Economic Institutions of Capitalism. Free Press, New York."
 },
 {
  "name": "Woolcock",
  "year": "2000",
  "text": "Woolcock, M., Narayan, D., 2000. Social capital: Implications for development theory, research, and policy. World Bank Research Observer 15(2), 225–249."
 },
 {
  "name": "Wooldridge",
  "year": "2010",
  "text": "Wooldridge, J.M., 2010. Econometric Analysis of Cross Section and Panel Data, 2nd ed. MIT Press, Cambridge, MA."
 },
 {
  "name": "World Bank",
  "year": "2015",
  "text": "World Bank, 2015. Malaysia among Most Urbanized Countries in East Asia. World Bank Feature Story, Washington, DC."
 },
 {
  "name": "World Bank",
  "year": "2017",
  "text": "World Bank, 2017. Malaysia’s land policies and administration offer useful examples to developing countries. Press release, 15 November 2017. World Bank, Washington, DC."
 },
 {
  "name": "Yin",
  "year": "2018",
  "text": "Yin, R.K., 2018. Case Study Research and Applications: Design and Methods, 6th ed. SAGE, Thousand Oaks, CA."
 },
 {
  "name": "Yusoff",
  "year": "2024",
  "text": "Yusoff, N.S., Rashid, M.F., Abd Halim, N., 2024. Factors impacting the wellbeing of rural households in Malaysia’s rural settlements. Planning Malaysia 22(2), 382–393."
 },
 {
  "name": "Zhou",
  "year": "2020",
  "text": "Zhou, Y., Li, X., Liu, Y., 2020. Rural land system reforms in China: History, issues, measures and prospects. Land Use Policy 91, 104330."
 }
];
