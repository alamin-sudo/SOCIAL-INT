// Builds the revised Supplementary Material (v14) from outputs/.
const fs = require("fs");
const path = require("path");
const L = require("./lib");
const { D, p, h1, h2, tableTitle, table, note, f, pv, star, styles, section, save } = L;
const ROOT = path.resolve(__dirname, "..");
const R = JSON.parse(fs.readFileSync(path.join(ROOT, "outputs/results.json")));
const csv = (n) => fs.readFileSync(path.join(ROOT, "outputs/tables", n), "utf8").trim().split("\n").map(l => l.split(","));
const esc = (s) => String(s).replace(/\*/g, "\\*");
const CASES = { 1: "FELDA Serting Hilir", 2: "Baling", 3: "Permatang Pauh", 4: "Mersing", 5: "Ranau", 6: "Kg. Sinulihan", 7: "Kapit" };

const b = [];
const P = (t, o) => b.push(p(t, o));
const H1 = (t) => b.push(h1(t));
const H2 = (t) => b.push(h2(t));

b.push(new D.Paragraph({ alignment: D.AlignmentType.CENTER, spacing: { after: 120 }, children: L.runs("**Supplementary Material**", { size: 28 }) }));
b.push(new D.Paragraph({ alignment: D.AlignmentType.CENTER, spacing: { after: 300 }, children: L.runs("**Social Interaction, Property Rights and the Circulation of Residential Land Use Rights: A Multiple Case Survey of Seven Rural Tenure Settings in Malaysia**") }));

H1("S1. Principal concepts and Malaysia's land use classification system");
H2("S1.1 Definitions in legal and sociological register");
P(`Seven concepts carry analytical weight in the study. Each has a legal meaning and a sociological meaning, and the two do not always coincide.`);
P(`**Land tenure.** In legal terms, land tenure is the bundle of rights and obligations governing the holding of land, including the conditions under which the holding may be terminated (Buang, 2007). In sociological terms, tenure is a social relationship among people with respect to land, not simply a relationship between a person and a thing. Its stability depends on collective acknowledgement as much as on registration.`);
P(`**Land rights.** Legally, land rights are the enforceable entitlements attaching to a holding: rights of use, of derived income, of transfer and of exclusion (Alchian and Demsetz, 1972; Barzel, 1997). Sociologically, rights are claims recognised as legitimate by a relevant community. Legitimacy and legality may diverge, and that divergence is central to customary contexts.`);
P(`**Residential land use rights.** In Malaysian law, the residential land use right entitles its holder to occupy and use a residential parcel, defined by the category of land use and by the express conditions endorsed on the title, with its legal basis in the National Land Code 1965 (Buang, 2007; Maidin and Syed Abdul Kader, 2022). Sociologically, the residential parcel is the physical anchor of household identity and lineage continuity in the kampung, and the site of inheritance expectation and of ritual and kin obligation.`);
P(`**Circulation of residential land use rights.** Circulation denotes transfer of the use right by lease, sublease, tenancy or assignment while registered ownership remains with the original proprietor. It is legally distinct from alienation of the title. Sociologically, it is a visible act, observed by neighbours and interpreted by kin, and that visibility makes it susceptible to social influence.`);
P(`**Land reform.** Legally, land reform is deliberate state alteration of the distribution or governance of land rights. Sociologically, it renegotiates the settled expectations a community holds about land, and so proceeds only as fast as those expectations can be revised.`);
P(`**Social structure.** Social structure is the relatively durable pattern of relations, positions and norms that situates individual action (Granovetter, 1985). Within Social Interaction Theory it determines the composition of the reference group and the weight attached to it (Durlauf and Ioannides, 2010).`);
P(`**Global and local social interaction.** *Global social interaction* is influence exerted by the village-wide distribution of attitudes; *local social interaction* is influence exerted by the immediate kin, neighbour and friendship network (Brock and Durlauf, 2001). "Global" denotes the whole reference population rather than an international scale.`);
H2("S1.2 The Malaysian land use classification system");
P(`Malaysian land administration operates under a Torrens registration system (Buang, 2007), introduced in Peninsular Malaysia by the National Land Code 1965. Title is indefeasible upon registration, subject to statutory exceptions. Land is a state matter under the Federal Constitution, so the states rather than the Federation administer it. Every alienated parcel carries a category of land use (agriculture, building or industry), and express conditions and restrictions in interest are endorsed on the document of title. A residential holding is a parcel within the building category with conditions specifying residential use. Restrictions in interest may require state consent before transfer, lease or charge, and are the principal legal friction affecting circulation.`);
P(`Five tenure regimes are relevant to rural residential land:`);
P(`**National Land Code holdings.** Ordinary alienated land held under final or qualified title, subject to category and express conditions. Circulation is legally straightforward where no restriction in interest applies.`);
P(`**Malay Reserve Land.** Land gazetted under state Malay Reservation Enactments. Dealings are confined to persons of the defined Malay class, so circulation is permitted but the pool of eligible counterparties is restricted (Buang, 2013).`);
P(`**Group settlement land, including FELDA schemes.** Settlement lots under the Land (Group Settlement Areas) Act 1960 are subject to statutory restrictions on subdivision, charge and transfer, and succession rules are designed to prevent fragmentation (Barau and Said, 2016).`);
P(`**Sarawak native customary rights land.** Rights acquired under the Sarawak Land Code, including Section 6 communal grants. The underlying claim is communal or lineage based, and circulation typically requires community-level assent (Ngidang, 2002; Majid Cooke, 2006; Azima et al., 2024).`);
P(`**Sabah native title and customary land.** Holdings under the Sabah Land Ordinance (Cap. 68). Native title may be transferred only among natives, and communal titles are held collectively (SUHAKAM, 2013).`);
P(`These regimes differ in the legal divisibility of the use right, in the transaction cost of a dealing, and in whose consent a dealing requires. The multiple case design in Section 3.1 of the main text is built on these differences.`);

H1("S2. Theoretical framework: axioms, framework distinction and variable mapping");
H2("S2.1 The four axioms of Social Interaction Theory");
P(`*Axiom 1, interdependence.* Individual utility from an action depends on the expected actions of a reference group, not on private returns alone.`);
P(`*Axiom 2, rational expectations.* Individuals form subjective expectations of group behaviour that are consistent in equilibrium with actual group behaviour.`);
P(`*Axiom 3, separability.* Private and social utility enter additively, so the social term can in principle be identified separately.`);
P(`*Axiom 4, conformity.* The social term is increasing in the alignment between the individual action and the expected group action.`);
P(`Axiom 3 carries the identification burden: without separability the interaction coefficient has no structural interpretation. Axiom 2 generates the reflection problem discussed in Section 3.6 of the main text, because it makes the expectation a function of the same population whose behaviour is being explained. Because the study measures perceived rather than actual group attitudes, Axiom 2 is not tested directly.`);
H2("S2.2 Theoretical and conceptual frameworks distinguished");
P(`A theory is a systematic explanation of a class of phenomena, comprising constructs, propositions and boundary conditions. A model is a formal or diagrammatic representation of a theory or part of one, so the term "theoretical model" conflates two distinct objects (Babbie, 2021; Bhattacherjee, 2012; Adu and Miles, 2024). A **theoretical framework** is the established theory, or set of theories, adopted as an explanatory lens. It is borrowed rather than constructed, and commits the study to particular assumptions (Ravitch and Riggan, 2017; Bingham et al., 2023). Here it is Social Interaction Theory extended by three complementary lenses, with the axioms in Section S2.1. A **conceptual framework** is constructed for the specific study. It translates the theoretical framework into variables, relationships and boundaries (Ravitch and Carl, 2021; Adu and Miles, 2024), and appears as Figure 1 of the main text. The relation is directional: the conceptual framework may contain no relationship the theoretical framework cannot justify. Table S1 applies that test to every variable.`);
b.push(tableTitle("**Table S1.** Variable definitions, measurement and theoretical justification."));
b.push(table(["Variable", "Measurement", "Governing lens", "Expected sign and reasoning"], [
  ["Circulation (dependent)", "1 if the household has circulated, has decided to circulate, or is likely to circulate; 0 otherwise", "Social Interaction Theory", "Outcome"],
  ["Global social interaction (GSI\\*)", "Reported attitude toward circulation at village level; continuous, GSI\\* = 2 × GSI, range [0, 1]; higher = more permissive", "Social Interaction Theory", "Positive (H1)"],
  ["Local social interaction (LSI)", "Reported attitude toward circulation within the close network (kin, friends, neighbours); continuous, range [0, 1]; higher = more permissive", "Social Interaction Theory; Social Capital Theory", "Positive (H2)"],
  ["Age", "Age of household head, years", "Theory of Planned Behaviour", "Negative: shorter horizon, stronger attachment to inherited land"],
  ["Education", "Years of formal schooling", "Theory of Planned Behaviour", "Positive: perceived control over an unfamiliar procedure"],
  ["Married", "1 = currently married", "Social Capital Theory", "Ambiguous: denser bonding ties, second decision maker"],
  ["Religious belief", "1 = yes", "Institutional Theory", "Ambiguous: exposure to normative institutions governing obligation"],
  ["Self-evaluated health", "1 = healthy; 0 = not healthy or unsure", "Theory of Planned Behaviour", "Ambiguous: need for rental income vs capacity to transact"],
  ["City living period", "Years lived in an urban area", "Theory of Planned Behaviour; Institutional Theory", "Positive: familiarity with formal rental markets"],
  ["Occupation", "Farming (reference); mixed livelihood; non-farm", "Property Rights Theory", "Positive for non-farm: lower dependence on the homestead"],
  ["Family size", "Household members", "Property Rights Theory", "Negative: competing internal claims on space"],
  ["Household splitting for a son", "1 = splitting required", "Property Rights Theory", "Negative: anticipated residual claim"],
  ["Family net wealth", "Net financial assets, MYR 10,000", "Property Rights Theory", "Ambiguous: less need for income, more capacity for transaction costs"],
  ["Homestead area", "Building plus courtyard area, m^{2}", "Property Rights Theory", "Negative: higher option value of the undivided holding"],
  ["Land management right circulation", "1 = agricultural land management right has been, will be, or is likely to be circulated", "Institutional Theory", "Positive: familiarity, lower perceived transaction cost"],
  ["Case fixed effects", "Seven cases", "Institutional Theory", "Absorb tenure regime, state administration, local markets"],
], [2000, 2726, 1800, 2500], { size: 17 }));

H1("S3. Extended methodological justification");
H2("S3.1 The multiple case design");
P(`**Why a case design.** Circulation cannot be detached from its institutional container, because the legal meaning of the act differs across tenure regimes (Section S1.2). A design that pooled households without regard to container would answer a question that is not well posed (Yin, 2018).`);
P(`**Why multiple cases.** A single case could establish that the mechanism operates in one tenure setting, but not its scope conditions, which are the subject of RQ3. Multiple cases permit comparison across containers (Stake, 2005; Gerring, 2017).`);
P(`**Replication logic.** Following Yin (2018), cases 1 to 4 (Peninsular, Torrens registration with varying restriction) form a literal replication set, in which similar results are predicted. Cases 5 to 7 (East Malaysian native title and communal regimes) form a theoretical replication set, in which weaker results are predicted because community-level consent may displace individual decision making. Section 4.5 of the main text reports that the literal replication holds but the theoretical replication is not confirmed: associations in cases 5 to 7 are not significantly weaker.`);
P(`**Case selection and comparability.** Cases were selected by diverse-case logic, seeking maximum variation on tenure regime (Gerring, 2017). All seven are rural settlements in which households hold residential parcels with some legally recognised capacity to grant use rights to others, which licenses comparison (Ragin and Becker, 1992).`);
P(`**Analytical generalisation.** The study claims analytical generalisation to the theoretical framework, in Yin's sense, not statistical generalisation to the population of Malaysian rural households.`);
P(`**Selection bias.** Cases and mukims were selected purposively, so localities already engaged with land reform may be over-represented. Case fixed effects absorb differences between cases, but they do not remove this exposure, since selection operates on which cases enter the study. Within kampungs, households were recruited toward a target of 60 per case according to availability. Of 420 targeted households, ${R.n_households} were interviewed (${(100 * R.n_households / 420).toFixed(1)} per cent), often after repeat visits, since many households were hesitant to discuss land matters. Households that were not interviewed may differ systematically from those that were; if wariness about discussing land goes with caution about circulating it, the sample over-represents households open to circulation. Attempt-level records were not fully retained, so this cannot be tested. The sample supports comparison across tenure regimes. It does not support inference to rural Malaysia as a whole.`);
H2("S3.2 Sample size and power");
P(`For a two-sided test of one coefficient at α = 0.05 with 80 per cent power, detecting a partial correlation of 0.15 (Cohen's *f*^{2} ≈ 0.023) with about fifteen covariates requires roughly 350 observations (Cohen, 1988). Clustering inflates this requirement by the design effect 1 + (*m* − 1)ρ. With an average of ${(R.n_households / R.n_kampungs).toFixed(1)} households per kampung and an observed intraclass correlation of circulation of ${f(R.icc.Y, 3)}, the design effect is about ${(1 + (R.n_households / R.n_kampungs - 1) * R.icc.Y).toFixed(2)}, so the main models are adequately powered. The target of 420 interviews, 60 per case, allowed for non-response of up to 16.7 per cent; achieved non-response was ${(100 - 100 * R.n_households / 420).toFixed(1)} per cent. The design is not, however, adequately powered for differences across cases: with about 50 households per case, the minimum detectable East Malaysia interaction is about ${f(R.hetero.GSIs.mde_east, 2)} for GSI\\* and ${f(R.hetero.LSI.mde_east, 2)} for LSI (main text, Section 4.5).`);

H1("S4. Derivation of the discrete choice model and spatial procedure");
H2("S4.1 The Brock and Durlauf self-consistency condition");
P(`Household *i* derives utility from the circulation decision ω_{i} ∈ {0, 1} according to Equation (1) of the main text. Under an independent extreme value disturbance the choice probability is logistic. Imposing rational expectations (Axiom 2) gives the self-consistency condition *E*[ω] = Λ(β′x̄ + *J*·*E*[ω]), where Λ(·) is the logistic function, *J* is the interaction weight and x̄ is the mean of observable characteristics. When *J* is large the map admits multiple fixed points, which is the formal source of the social multiplier. A setting with low *J* has a unique equilibrium; a setting with high *J* can support both high and low circulation equilibria under identical fundamentals. The present data measure perceived attitudes rather than equilibrium behaviour and so do not estimate *J* directly.`);
H2("S4.2 Spatial dependence");
P(`Moran's I was computed on the 42 kampung-level means of circulation, GSI\\* and LSI, using a binary four-nearest-neighbour weights matrix on approximate kampung centroids and one-sided permutation inference with 9,999 random permutations (Moran, 1950; Anselin, 1995). Coordinates were recorded approximately and are displaced for confidentiality, so the test is weak. Geographically weighted regression was not estimated. With households in seven spatially separate clusters and approximate positions, a continuous coefficient surface would describe differences between clusters rather than spatial variation, and the case-specific slopes in Table S5 answer that question directly.`);

H1("S5. Survey instruments");
P(`The two attitude items were drafted and administered in Bahasa Malaysia. The verbatim wording follows, with English translations prepared for reporting.`);
P(`**Global social interaction.** *"Secara umumnya, bagaimanakah anda menyifatkan pandangan penduduk kampung ini terhadap amalan menyewakan tanah tapak rumah?"* Generally, how would you characterise the attitude of this village's residents toward the practice of renting out residential home lots? Anchors: 1 = Negative (Menentang); 2 = Neutral (Berkecuali); 3 = Positive (Menyokong).`);
P(`**Local social interaction.** *"Bagaimanakah ahli keluarga terdekat dan jiran rapat anda memandang amalan ini?"* How do your close family members and immediate neighbours view this practice? Anchors: 1 = Negative; 2 = Neutral; 3 = Positive.`);
P(`The instruments were drafted and administered in Bahasa Malaysia, and over 95 per cent of interviews were conducted in Malay. In cases 5 to 7, bilingual enumerators gave oral field translation into Iban and Kadazandusun where respondents required it. English versions of the items were prepared after fieldwork for reporting purposes and were not used in administration. A pilot with 30 households tested item comprehension, anchors and interview flow before full fieldwork.`);
const kc = csv("tableS2_kampung_counts.csv").slice(1);
const byCase = {};
kc.forEach(([c, k, n]) => { (byCase[c] = byCase[c] || []).push(+n); });
b.push(tableTitle("**Table S2.** Achieved sample by case and kampung."));
b.push(table(["Case", "Site", "Kampungs", "Households", "Households per kampung", "Circulation rate"],
  Object.keys(byCase).map(c => {
    const v = byCase[c]; const r = R.cases.rates[c];
    return [c, CASES[c], v.length, v.reduce((a, x) => a + x, 0), v.join(", "), f(r.rate, 3)];
  }).concat([["Total", "", R.n_kampungs, R.n_households, `range ${R.kampung_n.min}–${R.kampung_n.max}`, f(R.desc.Y.mean, 3)]]),
  [700, 2000, 1000, 1200, 2526, 1600]));
b.push(note(`Note: Kampung names are withheld to protect participant confidentiality, as the ethics approval requires. Kampungs are listed in identifier order within each case. Attempt-level records were not fully retained, so attempted interviews are not reported.`));

H1("S6. Additional results");
const s3 = csv("tableS3_robustness_full.csv");
b.push(tableTitle("**Table S3.** Robustness: winsorisation and Likert substitution, full estimates."));
const lab = { "GSI*": "GSI\\*", "Village-wide expectation (1\u20137)": "Village-wide expectation (1–7)" };
b.push(table(["Variable", "(1) Winsorised, GSI\\*", "(2) Winsorised, LSI", "(3) Village-wide expectation", "(4) Close-group expectation"],
  s3.slice(1).map(r => [esc(lab[r[0]] || r[0]), ...r.slice(1).map(x => esc(x) || "—")]),
  [2626, 1600, 1600, 1600, 1600], { size: 16 }));
b.push(note(`Note: Linear probability models with case fixed effects; kampung-clustered standard errors in parentheses. \\*\\*\\* p < 0.01, \\*\\* p < 0.05, \\* p < 0.10. Columns (1) and (2) winsorise continuous variables at the 1st and 99th percentiles. Columns (3) and (4) replace the constructed indices with the seven-point Likert expectation items, on the same estimation samples as the baselines.`));
const AR = R.age_robust;
const arow = (lab, g, l) => [lab, `${f(g.b)}${star(g.p)} (${f(g.se)})`, g.n, `${f(l.b)}${star(l.p)} (${f(l.se)})`, l.n];
b.push(tableTitle("**Table S3, panel B.** Sensitivity of the interaction coefficients to the coding of approximate ages."));
b.push(table(["Specification", "GSI\\*", "N", "LSI", "N"], [
  arow("Baseline (linear age)", { ...R.main.G.coef.GSIs, n: R.main.G.fit.n }, { ...R.main.L.coef.LSI, n: R.main.L.fit.n }),
  arow("Adding an indicator for age recorded as 70", AR.GSIs.indicator, AR.LSI.indicator),
  arow("Age bands, with a separate category for age recorded as 70", AR.GSIs.bands, AR.LSI.bands),
  arow("Excluding households with age recorded as 70", AR.GSIs.exclude, AR.LSI.exclude),
], [3826, 1800, 600, 1800, 1000]));
b.push(note(`Note: Linear probability models with full controls and case fixed effects; kampung-clustered standard errors in parentheses. \\*\\*\\* p < 0.01. Respondents who could not state their exact age were recorded as 70 (${R.age70.n} heads). Age bands: under 35 (reference), 35–44, 45–54, 55–64, 65–69, and age recorded as 70.`));
const pg = R.robust.probit_G, pl = R.robust.probit_L;
b.push(tableTitle("**Table S4.** Probit estimates of the interaction associations."));
b.push(table(["Quantity", "Probit, GSI\\*", "Probit, LSI"], [
  ["Index coefficient (SE)", `${f(pg.b)}${star(pg.p)} (${f(pg.se)})`, `${f(pl.b)}${star(pl.p)} (${f(pl.se)})`],
  ["Average marginal effect (SE)", `${f(pg.ame)}${star(pg.ame_p)} (${f(pg.ame_se)})`, `${f(pl.ame)}${star(pl.ame_p)} (${f(pl.ame_se)})`],
  ["McFadden pseudo-R^{2}", f(pg.pseudo_r2), f(pl.pseudo_r2)],
  ["Log likelihood", f(pg.llf, 2), f(pl.llf, 2)],
  ["Range of fitted probabilities", `${f(pg.pmin)}–${f(pg.pmax)}`, `${f(pl.pmin)}–${f(pl.pmax)}`],
  ["Converged", pg.converged ? "Yes" : "No", pl.converged ? "Yes" : "No"],
  ["Observations", pg.n, pl.n],
], [3626, 2700, 2700]));
b.push(note(`Note: Full control vector and case fixed effects; kampung-clustered standard errors. Fitted probabilities lie strictly inside the unit interval, and there is no separation.`));
b.push(tableTitle("**Table S5.** Case-specific slopes from Equation (4) of the main text."));
const hG = R.hetero.GSIs, hL = R.hetero.LSI;
const cs = (t) => `${f(t.b)} (${f(t.se)})`;
b.push(table(["Case", "Site", "GSI\\* slope (SE)", "LSI slope (SE)"],
  [1, 2, 3, 4, 5, 6, 7].map(c => [c, CASES[c], cs(hG.case[c]), cs(hL.case[c])]).concat([
    ["", "Pooled (Table 3)", cs(R.main.G.coef.GSIs), cs(R.main.L.coef.LSI)],
    ["", "Equality of seven slopes", `F = ${f(hG.wald.F, 2)}, p ${pv(hG.wald.p)}`, `F = ${f(hL.wald.F, 2)}, p ${pv(hL.wald.p)}`]]),
  [800, 2826, 2700, 2700]));
b.push(note(`Note: One pooled model per measure, with case-specific slopes, full controls and case fixed effects; kampung-clustered standard errors. The equality test uses the t-based F distribution with 6 and 41 degrees of freedom.`));
b.push(tableTitle("**Table S6.** Moran's I for kampung-level means."));
b.push(table(["Variable", "Moran's I", "E[I]", "Permutation p (one-sided)", "Kampungs"],
  [["Circulation rate", "Y"], ["GSI\\*", "GSIs"], ["LSI", "LSI"]].map(([l, k]) => [l, f(R.moran[k].I), f(R.moran[k].EI), f(R.moran[k].p, 3), R.moran[k].n]),
  [2826, 1400, 1400, 2200, 1200]));
b.push(note(`Note: Binary four-nearest-neighbour weights on approximate kampung centroids; 9,999 permutations.`));

H1("S7. The community land forum");
P(`**Convenor and composition.** The District Office, with the ketua kampung and the Village Development and Security Committee. Membership should include at least two households that have completed a dealing, to serve as peer references. The forum addresses the close-network channel, which is associated with circulation in all specifications (main text, Section 4.2).`);
P(`**Function one, procedural clarification.** District Land Office staff would explain the applicable restriction in interest, the consent requirement, the documentation and the fee schedule. Content must be specific to the tenure regime of the mukim, because consent requirements differ materially across the five regimes (Section S1.2).`);
P(`**Function two, family agreement.** A voluntary, documented family agreement on use of the homestead, witnessed at the forum, could reduce uncertainty about kin claims. The present data do not show an association between anticipated household splitting and circulation, so this function rests on its procedural value rather than on our estimates. A standard form could be developed with the relevant Syariah and civil succession authorities.`);
P(`**Function three, counterparty matching.** In Malay Reserve Land the counterparty pool is legally restricted. A mukim-level register of eligible interested parties addresses that constraint directly.`);
P(`**Roll-out and evaluation.** The associations do not differ detectably across tenure regimes, so the data give no basis for sequencing the forum by regime. Randomising the order in which mukims receive the forum would allow its effect on circulation to be estimated causally. In native customary and communal settings, documentation of rights and community-level free, prior and informed consent should precede any promotion of circulation.`);

H1("Supplementary references");
P(`Cohen, J., 1988. Statistical Power Analysis for the Behavioral Sciences, 2nd ed. Lawrence Erlbaum, Hillsdale, NJ.`, { align: D.AlignmentType.LEFT, indent: { left: 360, hanging: 360 } });
P(`Majid Cooke, F., 2006. Expanding state spaces using 'idle' native customary land in Sarawak. In: Majid Cooke, F. (Ed.), State, Communities and Forests in Contemporary Borneo. ANU Press, Canberra, 25–44.`, { align: D.AlignmentType.LEFT, indent: { left: 360, hanging: 360 } });
P(`All other works cited in this Supplementary Material appear in the reference list of the main text.`);

const doc = new D.Document({ styles: styles(), sections: [section(b)] });
save(doc, process.argv[2] || path.join(ROOT, "manuscript/Supplementary_Material_v16.docx"));
