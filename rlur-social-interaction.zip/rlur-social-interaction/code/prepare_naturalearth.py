"""
Build the two small Natural Earth extracts used by Figure 2 (fig2_study_location.py).

Source : Natural Earth vector data (public domain, https://www.naturalearthdata.com), obtained from the
         official GitHub mirror https://github.com/nvkelso/natural-earth-vector, pinned to one commit.
Layers : 1:50m admin-0 countries   (context map and neighbouring countries)
         1:10m admin-1 states      (Malaysian states only)
Output : data/external/natural_earth/ne_50m_admin_0_countries_seasia.geojson
         data/external/natural_earth/ne_10m_admin_1_malaysia.geojson
         data/external/natural_earth/SOURCE.json   (source URLs, commit and SHA-256 of the full downloads)

The extracts are committed to the repository, so this script only needs to be run to rebuild them.
It needs network access and nothing beyond the standard library.

Run   : python code/prepare_naturalearth.py
"""
import hashlib, json, os, urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEST = os.path.join(ROOT, "data", "external", "natural_earth")
COMMIT = "ca96624a56bd078437bca8184e78163e5039ad19"          # nvkelso/natural-earth-vector, June 2022
BASE = f"https://raw.githubusercontent.com/nvkelso/natural-earth-vector/{COMMIT}/geojson/"
BBOX = (88.0, -12.0, 130.0, 27.0)                              # lon_min, lat_min, lon_max, lat_max (South-East Asia)
NDIG = 4                                                       # coordinate precision kept (about 11 m)

def fetch(name):
    with urllib.request.urlopen(BASE + name, timeout=120) as r:
        raw = r.read()
    return raw, hashlib.sha256(raw).hexdigest()

def rnd(c):
    return [round(c[0], NDIG), round(c[1], NDIG)]

def walk(geom):
    t, c = geom["type"], geom["coordinates"]
    if t == "Polygon":
        return {"type": t, "coordinates": [[rnd(p) for p in ring] for ring in c]}
    if t == "MultiPolygon":
        return {"type": t, "coordinates": [[[rnd(p) for p in ring] for ring in poly] for poly in c]}
    raise ValueError(t)

def rings(geom):
    polys = [geom["coordinates"]] if geom["type"] == "Polygon" else geom["coordinates"]
    for poly in polys:
        yield from poly

def in_bbox(geom):
    pts = [p for ring in rings(geom) for p in ring]
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    return not (max(xs) < BBOX[0] or min(xs) > BBOX[2] or max(ys) < BBOX[1] or min(ys) > BBOX[3])

def write(name, feats, keep):
    fc = {"type": "FeatureCollection", "features": [
        {"type": "Feature", "properties": {k: f["properties"].get(k) for k in keep}, "geometry": walk(f["geometry"])}
        for f in feats]}
    path = os.path.join(DEST, name)
    with open(path, "w") as fh:
        json.dump(fc, fh, separators=(",", ":"))
    print(f"{name}: {len(feats)} features, {os.path.getsize(path)/1e6:.2f} MB")

os.makedirs(DEST, exist_ok=True)
src = {}

raw, sha = fetch("ne_50m_admin_0_countries.geojson"); src["ne_50m_admin_0_countries.geojson"] = sha
fc = json.loads(raw)
feats = [f for f in fc["features"] if f["geometry"] and in_bbox(f["geometry"])]
write("ne_50m_admin_0_countries_seasia.geojson", feats, ["ADMIN", "ISO_A3", "NAME"])

raw, sha = fetch("ne_10m_admin_1_states_provinces.geojson"); src["ne_10m_admin_1_states_provinces.geojson"] = sha
fc = json.loads(raw)
feats = [f for f in fc["features"] if f["properties"].get("admin") == "Malaysia"]
write("ne_10m_admin_1_malaysia.geojson", feats, ["name", "admin", "iso_3166_2"])

with open(os.path.join(DEST, "SOURCE.json"), "w") as fh:
    json.dump({"source": "Natural Earth (public domain), https://www.naturalearthdata.com",
               "mirror": "https://github.com/nvkelso/natural-earth-vector", "commit": COMMIT, "bbox_lonlat": BBOX,
               "coordinate_decimals": NDIG, "sha256_of_full_downloads": src}, fh, indent=1)
print("Wrote SOURCE.json")
