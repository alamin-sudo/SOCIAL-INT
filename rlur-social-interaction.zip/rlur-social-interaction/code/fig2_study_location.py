"""
Figure 2. Study location (drawn with matplotlib from Natural Earth boundaries).

Panels  (a) Malaysia within South-East Asia, with the extents of (b) and (c)
        (b) Peninsular Malaysia, cases 1-4
        (c) Sabah and Sarawak, cases 5-7
        (d) case names and tenure regimes (Table 1)

Case markers are the mean of the approximate kampung centroids of each case
(data/raw/kampung_centroids_approx_-AQ.csv), rounded to 0.01 degree (about 1 km). Kampung and
household positions are never drawn.

Boundaries: Natural Earth 1:10m admin-1 (Malaysian states) and 1:50m admin-0 (countries), as trimmed
extracts in data/external/natural_earth/ (rebuilt by code/prepare_naturalearth.py). WGS 84 (EPSG:4326),
plotted as plain longitude/latitude with the aspect corrected for latitude.

Output: outputs/Figure2_study_location.png (300 dpi), .pdf (vector) and outputs/fig2_case_locations.csv
Run   : python code/fig2_study_location.py
Needs : matplotlib, numpy, pandas
"""
import json, os, sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
from matplotlib.path import Path
from matplotlib.patches import PathPatch, Rectangle

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")
NE = os.path.join(ROOT, "data", "external", "natural_earth")
CEN = os.path.join(ROOT, "data", "raw", "kampung_centroids_approx_-AQ.csv")
HH = os.path.join(ROOT, "data", "raw", "households-2_with_gsis_-_AQ.csv")
os.makedirs(OUT, exist_ok=True)

BLUE, ORANGE, INK = "#2B5C8A", "#C4621A", "#1F2933"
OCEAN, LAND, MY_BEIGE, MY_BLUE, EDGE = "#F3F6F9", "#E4E4E4", "#F3EFE8", "#9FB3CC", "#8C8C8C"
plt.rcParams.update({"font.size": 8, "axes.linewidth": 0.8})

# ------------------------------------------------------------------ case information
# Display labels follow Table 1 of the paper (site, state, tenure regime).
CASES = {
    1: ("FELDA Serting Hilir", "Negeri Sembilan", "Group settlement (GSA 1960, FELDA)"),
    2: ("Baling", "Kedah", "Malay Reserve Land"),
    3: ("Permatang Pauh", "Pulau Pinang", "NLC alienated land, urban fringe"),
    4: ("Mersing", "Johor", "NLC alienated land, mixed"),
    5: ("Ranau", "Sabah", "Sabah native title"),
    6: ("Kg. Sinulihan", "Sabah", "Sabah native and communal title"),
    7: ("Kapit", "Sarawak", "Sarawak NCR, Section 6 communal grant"),
}
hh = pd.read_csv(HH, encoding="latin-1")
hh = hh[hh["survey_id"].notna()]
data_sites = hh.groupby(hh["city_fe"].astype(int))["city_name"].first()
for c, (site, _, _) in CASES.items():                       # the labels above must match the data file
    assert data_sites[c].startswith(site), (c, data_sites[c], site)

cen = pd.read_csv(CEN)
assert len(cen) == 42 and cen.groupby("case").size().eq(6).all()
loc = cen.groupby("case")[["lat", "lon"]].mean().round(2)
loc.index = loc.index.astype(int)
loc.to_csv(os.path.join(OUT, "fig2_case_locations.csv"), index_label="case")


# ------------------------------------------------------------------ geometry helpers
def ring_path(ring, ccw):
    """Closed ring as (vertices, codes); orientation forced so that holes cut out under the nonzero rule."""
    v = np.asarray(ring, float)
    area = 0.5 * np.sum(v[:-1, 0] * v[1:, 1] - v[1:, 0] * v[:-1, 1])
    if (area > 0) != ccw:
        v = v[::-1]
    codes = np.full(len(v), Path.LINETO); codes[0] = Path.MOVETO; codes[-1] = Path.CLOSEPOLY
    return v, codes


def geom_path(geom):
    polys = [geom["coordinates"]] if geom["type"] == "Polygon" else geom["coordinates"]
    verts, codes = [], []
    for poly in polys:
        for k, ring in enumerate(poly):
            v, c = ring_path(ring, ccw=(k == 0))
            verts.append(v); codes.append(c)
    return Path(np.concatenate(verts), np.concatenate(codes))


def load(name):
    with open(os.path.join(NE, name)) as fh:
        return json.load(fh)["features"]


try:
    countries = load("ne_50m_admin_0_countries_seasia.geojson")
    states = load("ne_10m_admin_1_malaysia.geojson")
except FileNotFoundError:
    sys.exit("Natural Earth extracts missing: run  python code/prepare_naturalearth.py  first.")

country_path = {f["properties"]["ADMIN"]: geom_path(f["geometry"]) for f in countries}
state_paths = [geom_path(f["geometry"]) for f in states]


def draw_land(ax, detail):
    """detail=False: countries only (panel a). detail=True: Malaysian states on neighbouring countries."""
    for name, p in country_path.items():
        if name == "Malaysia":
            ax.add_patch(PathPatch(p, fc=MY_BEIGE if detail else MY_BLUE, ec="none" if detail else EDGE,
                                   lw=0.4, zorder=2))
        else:
            ax.add_patch(PathPatch(p, fc=LAND, ec="white", lw=0.5, zorder=1))
    if detail:
        for p in state_paths:
            ax.add_patch(PathPatch(p, fc=MY_BEIGE, ec=EDGE, lw=0.5, zorder=3))


def km_per_deg_lon(lat):
    return 111.32 * np.cos(np.radians(lat))


def scale_bar(ax, lon0, lat0, km, lat_ref):
    dl = km / km_per_deg_lon(lat_ref)
    ax.plot([lon0, lon0 + dl], [lat0, lat0], color=INK, lw=3.0, solid_capstyle="butt", zorder=8)
    ax.text(lon0 + dl / 2, lat0 + 0.035 * np.diff(ax.get_ylim())[0], f"{km} km", ha="center", va="bottom",
            fontsize=7, zorder=8)


def north_arrow(ax, x=0.93, y=0.84):
    ax.annotate("", xy=(x, y + 0.075), xytext=(x, y), xycoords="axes fraction",
                arrowprops=dict(arrowstyle="-|>", color=INK, lw=1.0, mutation_scale=7), zorder=9)
    ax.text(x, y - 0.012, "N", transform=ax.transAxes, ha="center", va="top", fontsize=8, fontweight="bold",
            zorder=9)


def axes_for(left, top, width, extent, fig_w, fig_h):
    """Axes of fixed width whose height follows from the extent and the latitude-corrected aspect."""
    lon0, lon1, lat0, lat1 = extent
    asp = 1 / np.cos(np.radians((lat0 + lat1) / 2))
    height = width * (lat1 - lat0) / ((lon1 - lon0) * np.cos(np.radians((lat0 + lat1) / 2)))
    ax = fig.add_axes([left / fig_w, (fig_h - top - height) / fig_h, width / fig_w, height / fig_h])
    ax.set_xlim(lon0, lon1); ax.set_ylim(lat0, lat1); ax.set_aspect(asp, adjustable="box")
    ax.set_facecolor(OCEAN)
    return ax, height


def style_geo_ticks(ax, xt, yt, labels=True):
    ax.set_xticks(xt); ax.set_yticks(yt)
    ax.tick_params(length=2.5, width=0.7, labelsize=7, labelbottom=labels, labelleft=labels)
    if labels:
        ax.set_xlabel("Longitude (°E)", fontsize=8, labelpad=2); ax.set_ylabel("Latitude (°N)", fontsize=8, labelpad=2)


def halo(t):
    t.set_path_effects([pe.withStroke(linewidth=2.2, foreground="white")])
    return t


def title(ax, text):
    ax.set_title(text, loc="left", fontsize=9.5, fontweight="bold", pad=5)


# ------------------------------------------------------------------ figure frame
EXT_A = (94.0, 122.0, -7.5, 13.0)
EXT_B = (99.4, 104.9, 1.1, 6.95)
EXT_C = (109.4, 119.6, 0.55, 7.6)

FIG_W = 7.6
COL1_L, COL1_W = 0.62, 3.30
COL2_L, COL2_W = 4.50, 2.45
TOP = 0.38                                           # room for the panel titles
ROW_GAP = 0.88                                       # titles of row 2 + tick labels of row 1
FOOT = 0.95                                           # x-axis labels of row 2 and the footnote

# first pass for heights (a figure object is needed by axes_for, so build a throw-away figure)
fig = plt.figure(figsize=(FIG_W, 10))
_, h_a = axes_for(COL1_L, TOP, COL1_W, EXT_A, FIG_W, 10)
_, h_b = axes_for(COL2_L, TOP, COL2_W, EXT_B, FIG_W, 10)
_, h_c = axes_for(COL1_L, TOP, COL1_W, EXT_C, FIG_W, 10)
plt.close(fig)
row1 = max(h_a, h_b)
FIG_H = TOP + row1 + ROW_GAP + h_c + FOOT
fig = plt.figure(figsize=(FIG_W, FIG_H), facecolor="white")

# ------------------------------------------------------------------ (a) regional context
ax_a, _ = axes_for(COL1_L, TOP, COL1_W, EXT_A, FIG_W, FIG_H)
draw_land(ax_a, detail=False)
for ext, tag in [(EXT_B, "b"), (EXT_C, "c")]:
    ax_a.add_patch(Rectangle((ext[0], ext[2]), ext[1] - ext[0], ext[3] - ext[2], fc="none", ec="#9B2C2C", lw=1.1,
                             zorder=6))
    halo(ax_a.text(ext[0] + 0.1, ext[2] - 0.45, tag, color="#9B2C2C", fontsize=8, fontweight="bold", va="top", zorder=7))
for name, (x, y) in {"THAILAND": (101.0, 11.8), "VIETNAM": (107.6, 11.2), "PHILIPPINES": (119.0, 9.6),
                     "INDONESIA": (111.5, -5.3)}.items():
    ax_a.text(x, y, name, fontsize=6.3, color="#7C8794", ha="center", va="center", zorder=5)
ax_a.text(107.15, 2.6, "South China\nSea", fontsize=6.0, style="italic", color="#7C8794", ha="center", va="center", zorder=5, linespacing=1.1)
ax_a.text(107.15, 9.0, "MALAYSIA", fontsize=7, fontweight="bold", color=INK, ha="center", va="center", zorder=7)
style_geo_ticks(ax_a, [100, 110, 120], [-5, 0, 5, 10], labels=False)
ax_a.tick_params(labelbottom=True, labelleft=True, labelsize=6.5)
ax_a.set_xticklabels(["100°E", "110°E", "120°E"]); ax_a.set_yticklabels(["5°S", "0°", "5°N", "10°N"])
north_arrow(ax_a, x=0.93, y=0.09)
title(ax_a, "(a) Malaysia in Southeast Asia")

# ------------------------------------------------------------------ (b) Peninsular Malaysia, (c) Sabah and Sarawak
ax_b, _ = axes_for(COL2_L, TOP, COL2_W, EXT_B, FIG_W, FIG_H)
ax_c, _ = axes_for(COL1_L, TOP + row1 + ROW_GAP, COL1_W, EXT_C, FIG_W, FIG_H)

# label offsets in points, with horizontal alignment: chosen to stay clear of markers and coastlines
LABEL = {1: (-7, 3, "right"), 2: (7, 1, "left"), 3: (7, -9, "left"), 4: (7, -1, "left"),
         5: (7, 3, "left"), 6: (-8, -3, "right"), 7: (7, -2, "left")}
for ax, group, xt, yt, scale in [(ax_b, (1, 2, 3, 4), [100, 101, 102, 103, 104], [2, 3, 4, 5, 6], (99.75, 1.45, 100)),
                                 (ax_c, (5, 6, 7), [110, 112, 114, 116, 118], [1, 2, 3, 4, 5, 6, 7], (115.6, 0.95, 200))]:
    draw_land(ax, detail=True)
    style_geo_ticks(ax, xt, yt)
    for c in group:
        lat, lon = loc.loc[c, "lat"], loc.loc[c, "lon"]
        col = BLUE if c <= 4 else ORANGE
        ax.scatter([lon], [lat], s=46, color=col, edgecolor="white", linewidth=1.0, zorder=10)
        dx, dy, ha = LABEL[c]
        halo(ax.annotate(f"{c} {CASES[c][0]}", (lon, lat), xytext=(dx, dy), textcoords="offset points",
                         ha=ha, va="center", fontsize=7.2, zorder=11))
    scale_bar(ax, scale[0], scale[1], scale[2], lat_ref=(ax.get_ylim()[0] + ax.get_ylim()[1]) / 2)
    north_arrow(ax)
title(ax_b, "(b) Peninsular Malaysia: cases 1–4")
title(ax_c, "(c) Sabah and Sarawak: cases 5–7")

# ------------------------------------------------------------------ (d) case list
ax_d = fig.add_axes([COL2_L / FIG_W, ax_c.get_position().y0, COL2_W / FIG_W + 0.02, ax_c.get_position().height])
ax_d.set_xlim(0, 1); ax_d.set_ylim(0, 1); ax_d.axis("off")
title(ax_d, "(d) Cases and tenure regimes")
step = 1 / 7.0
for k, c in enumerate(CASES):
    y = 1 - (k + 0.5) * step
    ax_d.scatter([0.03], [y + 0.012], s=40, color=BLUE if c <= 4 else ORANGE, edgecolor="white", linewidth=0.8,
                 transform=ax_d.transAxes, clip_on=False)
    ax_d.text(0.10, y + 0.032, f"{c}  {CASES[c][0]}, {CASES[c][1]}", fontsize=7.2, fontweight="bold", va="center",
              transform=ax_d.transAxes)
    ax_d.text(0.10, y - 0.028, CASES[c][2], fontsize=6.8, color="#333333", va="center", transform=ax_d.transAxes)

fig.text(0.012, 0.012, "WGS 84 (EPSG:4326). Boundaries: Natural Earth 1:10m states, 1:50m countries. Markers show approximate\n"
                       "case locations only; kampung and household positions are not shown, to protect respondent confidentiality.",
         fontsize=6.4, color="#444444", ha="left", va="bottom", linespacing=1.3)

for ext in ("png", "pdf"):
    fig.savefig(os.path.join(OUT, f"Figure2_study_location.{ext}"), dpi=300, facecolor="white", metadata={"CreationDate": None} if ext == "pdf" else None)
plt.close(fig)

# ------------------------------------------------------------------ check: every case marker lies on Malaysian land
my = [state_paths[i] for i in range(len(state_paths))]
for c in CASES:
    pt = (loc.loc[c, "lon"], loc.loc[c, "lat"])
    on_land = any(p.contains_point(pt) for p in my)
    print(f"case {c} {CASES[c][0]:<20s} lat {pt[1]:6.2f} lon {pt[0]:7.2f}  on Malaysian land (1:10m): {on_land}")
print("Wrote outputs/Figure2_study_location.png and .pdf, outputs/fig2_case_locations.csv")
