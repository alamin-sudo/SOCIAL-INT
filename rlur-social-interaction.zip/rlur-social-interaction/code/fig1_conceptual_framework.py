"""
Figure 1. Conceptual framework (drawn with matplotlib; no data are used).

Boxes and arrows follow Section 2.5 of the paper:
  social structure -> global (GSI) and local (LSI) social interaction -> circulation  (H1, H2, both expected positive)
  tenure regime moderates both channels (RQ3, dashed arrows ending on the H1 and H2 paths)
  household attributes enter as controls (TPB, PRT, SCT = complementary lenses)

Output: outputs/Figure1_conceptual_framework.png (300 dpi) and .pdf (vector)
Run   : python code/fig1_conceptual_framework.py
Needs : matplotlib (numpy only through matplotlib)
"""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "outputs")
os.makedirs(OUT, exist_ok=True)

INK, BLUE, ORANGE = "#1F2933", "#2B5C8A", "#C4621A"
FILL = {"structure": "#EEF1F6", "interaction": "#E4ECF5", "outcome": "#F3E6E6", "context": "#F4EEE4"}

W, H = 100, 64                                    # canvas units (figure is 7.4 x 4.74 in)
fig, ax = plt.subplots(figsize=(7.4, 7.4 * H / W))
ax.set_xlim(0, W); ax.set_ylim(0, H); ax.set_aspect("equal"); ax.axis("off")
fig.subplots_adjust(0.005, 0.005, 0.995, 0.995)

TITLE_PT, BODY_PT = 8.4, 6.9


def box(x, y, w, h, title, body, kind, title_pt=TITLE_PT):
    """Rounded box: bold title at the top, body text centred in the space underneath
    (a box with no body gets its title centred instead)."""
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=1.6",
                                fc=FILL[kind], ec=INK, lw=1.1, zorder=2))
    if not body:
        ax.text(x + w / 2, y + h / 2, title, ha="center", va="center", fontsize=title_pt,
                fontweight="bold", color=INK, zorder=3, linespacing=1.25)
        return (x, y, w, h)
    n_title = title.count("\n") + 1
    title_h = 2.0 + 3.5 * n_title                      # space taken by the title block, canvas units
    ax.text(x + w / 2, y + h - 2.0, title, ha="center", va="top", fontsize=title_pt,
            fontweight="bold", color=INK, zorder=3, linespacing=1.15)
    ax.text(x + w / 2, y + (h - title_h) / 2 + 0.3, body, ha="center", va="center",
            fontsize=BODY_PT, color=INK, zorder=3, linespacing=1.38)
    return (x, y, w, h)


def arrow(p0, p1, color=INK, lw=1.6, ls="-", ms=11, z=4):
    ax.add_patch(FancyArrowPatch(p0, p1, arrowstyle="-|>", mutation_scale=ms, lw=lw, ls=ls, color=color,
                                 shrinkA=0, shrinkB=0, zorder=z, capstyle="butt"))


def on_path(p0, p1, t):
    return (p0[0] + t * (p1[0] - p0[0]), p0[1] + t * (p1[1] - p0[1]))


# ------------------------------------------------------------------ boxes
# column 1: social structure
box(1, 13, 21, 38, "Social structure",
    "Village leadership\n(ketua kampung, village\ndevelopment and\nsecurity committee)\n\nKinship and adat\n\nSpatial proximity\n\nDefines reference\ngroups and weights",
    "structure")
# column 2: global (top), tenure regime (middle), local (bottom)
G = box(30, 43, 30, 17, "Global social interaction (GSI)",
        "Perceived village attitude\nInformational learning\nNormative conformity\nMarket thickness", "interaction")
T = box(33, 26, 24, 12, "Tenure regime",
        "Legal friction by case\n(PRT, Institutional Theory)", "context")
L = box(30, 4, 30, 17, "Local social interaction (LSI)",
        "Perceived attitude of close\nfamily and neighbours\nBonding social capital\nKin as residual claimants", "interaction")
# column 3: outcome (middle) and household attributes (bottom)
C = box(76, 30, 23, 18, "Circulation of the\nresidential land\nuse right", "", "outcome")
Hh = box(76, 4, 23, 19, "Household attributes",
         "Age, education, occupation,\nfamily size, wealth,\nhomestead area, urban\nand land-market experience\n(TPB, PRT, SCT)", "context")

# ------------------------------------------------------------------ arrows
# social structure defines the reference groups
arrow((22, 41), (30, 50.5)); arrow((22, 23), (30, 13.5))
# H1 and H2: interaction channels -> circulation
h1_0, h1_1 = (60, 51.5), (76, 43.5)
h2_0, h2_1 = (60, 12.5), (76, 34.5)
arrow(h1_0, h1_1); arrow(h2_0, h2_1)
# household attributes -> circulation (controls)
arrow((87.5, 23), (87.5, 30))
# RQ3: tenure regime moderates both paths; arrowheads land ON the H1 and H2 paths
a1 = on_path(h1_0, h1_1, 0.50); a2 = on_path(h2_0, h2_1, 0.50)
arrow((57, 34.0), a1, color=ORANGE, lw=1.5, ls=(0, (4, 2.2)), ms=10, z=5)
arrow((57, 30.0), a2, color=ORANGE, lw=1.5, ls=(0, (4, 2.2)), ms=10, z=5)
ax.text(64.0, 32.0, "RQ3", color=ORANGE, fontsize=8.6, fontweight="bold", style="italic", ha="center", va="center")

# hypothesis labels, set clear of the arrows
ax.text(69.0, 52.4, "H1 (+)", color=BLUE, fontsize=8.6, fontweight="bold", ha="center", va="center")
ax.text(69.8, 16.2, "H2 (+)", color=BLUE, fontsize=8.6, fontweight="bold", ha="center", va="center")

for ext in ("png", "pdf"):
    fig.savefig(os.path.join(OUT, f"Figure1_conceptual_framework.{ext}"), dpi=300, facecolor="white", metadata={"CreationDate": None} if ext == "pdf" else None)
plt.close(fig)
print("Wrote outputs/Figure1_conceptual_framework.png and .pdf")
