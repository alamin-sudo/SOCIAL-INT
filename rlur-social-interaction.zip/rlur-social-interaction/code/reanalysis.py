"""
Reanalysis: Social interaction and residential land-use-right circulation, rural Malaysia (2023 survey).
One script, one input file. Every estimate, results table and data figure (Figures 3–5) is produced here.

Input : households-2_with_gsis_-_AQ.csv  (verified household file, rebuilt from the project's original data)
        kampung_centroids_approx_-AQ.csv (approximate kampung centroids)
Output: <repo>/outputs/  (clean data, dictionary, descriptives, tables, figures, log)

Run   : python code/reanalysis.py  [path_to_household_csv] [path_to_centroid_csv]   (defaults: data/raw/)
Needs : pandas, numpy, statsmodels, scipy, matplotlib
"""
import sys, os, io, contextlib
import numpy as np, pandas as pd
import statsmodels.formula.api as smf
from scipy import stats
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HH = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "data", "raw", "households-2_with_gsis_-_AQ.csv")
CEN = sys.argv[2] if len(sys.argv) > 2 else os.path.join(ROOT, "data", "raw", "kampung_centroids_approx_-AQ.csv")
OUT = os.path.join(ROOT, "outputs")
os.makedirs(OUT, exist_ok=True)
SEED = 20231
LOG = io.StringIO()
def log(*a):
    print(*a); print(*a, file=LOG)

# ---------------------------------------------------------------- 1. Load and clean
raw = pd.read_csv(HH, encoding="latin-1")          # file is Windows-1252/latin-1, not UTF-8
n_raw = len(raw)
df = raw[raw["survey_id"].notna()].copy()           # drops blank rows and the appended note rows
log(f"Rows read: {n_raw}; non-respondent rows dropped (blank/notes): {n_raw-len(df)}; respondents: {len(df)}")

df = df.rename(columns={
    "city_fe": "case", "circulation_DV": "circ",
    "likert_overall_avg_expectation": "D3_village_attitude",
    "likert_closegroup_expectation": "D4_close_attitude"})
int_cols = ["survey_id", "case", "region_fe", "kampung_id", "circ", "educational_background",
            "marriage_status", "religious_belief", "self_evaluated_health", "occupation_category",
            "family_scale", "household_splitting_son", "land_mgmt_right_circulation",
            "D3_village_attitude", "D4_close_attitude", "GSI", "LSI"]
for c in int_cols: df[c] = pd.to_numeric(df[c]).astype(int)
df["age"] = pd.to_numeric(df["age"])
assert df["survey_id"].is_unique and df.isna().sum().sum() == 0
assert df.groupby("kampung_id")["case"].nunique().max() == 1      # kampungs nested in cases
assert df.groupby("case")["region_fe"].nunique().max() == 1       # region nested in case -> collinear with case FE

# Derived variables
df["GSI01"] = (df["GSI"] - 1) / 2       # codes 1,2,3 -> 0, 0.5, 1 ; coefficient = code 3 vs code 1
df["LSI01"] = (df["LSI"] - 1) / 2
df["occ_byb"] = (df["occupation_category"] == 2).astype(int)
df["occ_nonfarm"] = (df["occupation_category"] == 3).astype(int)
df["age_topcoded"] = (df["age"] >= 70).astype(int)
df["wealth_floor"] = (df["family_net_wealth_MYR10k"] <= 1.0).astype(int)

CONT = ["age", "educational_background", "city_living_period_yr", "family_scale",
        "family_net_wealth_MYR10k", "homestead_area_m2"]
for c in CONT:
    lo, hi = df[c].quantile([.01, .99]); df[c + "_w"] = df[c].clip(lo, hi)

CTRL = ("age + educational_background + marriage_status + religious_belief + self_evaluated_health"
        " + city_living_period_yr + occ_byb + occ_nonfarm + family_scale + household_splitting_son"
        " + family_net_wealth_MYR10k + homestead_area_m2 + land_mgmt_right_circulation")
CTRL_W = " + ".join(t + "_w" if t in CONT else t for t in [s.strip() for s in CTRL.split("+")])
FE = " + C(case)"

df.to_csv(os.path.join(OUT, "analysis_dataset_verified.csv"), index=False)
os.makedirs(os.path.join(ROOT, "data", "processed"), exist_ok=True)
df.to_csv(os.path.join(ROOT, "data", "processed", "analysis_dataset_verified.csv"), index=False)

# ---------------------------------------------------------------- 2. Audit of GSI / LSI
log("\n=== GSI/LSI audit ===")
for v in ["GSI", "LSI"]:
    g = df.groupby("kampung_id")[v]
    n_var = (g.nunique() > 1).sum()
    # ICC(1) from one-way ANOVA
    k = df.groupby("kampung_id").size(); n0 = (len(df) - (k**2).sum()/len(df)) / (len(k)-1)
    msb = (k * (g.mean() - df[v].mean())**2).sum() / (len(k)-1)
    msw = ((df[v] - g.transform("mean"))**2).sum() / (len(df)-len(k))
    icc = (msb - msw) / (msb + (n0-1)*msw)
    log(f"{v}: values {sorted(df[v].unique())}; kampungs with >1 value: {n_var}/42; ICC(1) = {icc:.3f}; "
        f"share of variance within kampungs = {msw/(msw+max(msb-msw,0)/n0):.2f}")
log(f"Spearman GSI-LSI = {stats.spearmanr(df.GSI, df.LSI)[0]:.3f}; "
    f"GSI-D3 = {stats.spearmanr(df.GSI, df.D3_village_attitude)[0]:.3f}; "
    f"LSI-D4 = {stats.spearmanr(df.LSI, df.D4_close_attitude)[0]:.3f}; "
    f"D3-D4 = {stats.spearmanr(df.D3_village_attitude, df.D4_close_attitude)[0]:.3f}")

# ---------------------------------------------------------------- 3. Descriptives
desc_vars = ["circ", "GSI", "LSI", "D3_village_attitude", "D4_close_attitude", "age",
             "educational_background", "marriage_status", "religious_belief", "self_evaluated_health",
             "city_living_period_yr", "occ_byb", "occ_nonfarm", "family_scale", "household_splitting_son",
             "family_net_wealth_MYR10k", "homestead_area_m2", "land_mgmt_right_circulation",
             "age_topcoded", "wealth_floor"]
desc = df[desc_vars].agg(["count", "mean", "std", "min", "max"]).T.round(3)
desc.columns = ["N", "Mean", "SD", "Min", "Max"]; desc["N"] = desc["N"].astype(int)
desc.to_csv(os.path.join(OUT, "table2_descriptives.csv"))
bycase = df.groupby(["case", "city_name"]).agg(N=("circ", "size"), kampungs=("kampung_id", "nunique"),
         circulation=("circ", "mean"), GSI_mean=("GSI", "mean"), LSI_mean=("LSI", "mean"),
         D3_mean=("D3_village_attitude", "mean"), D4_mean=("D4_close_attitude", "mean"),
         age_mean=("age", "mean")).round(3)
bycase.to_csv(os.path.join(OUT, "descriptives_by_case.csv"))
dist = []
for v in ["GSI", "LSI"]:
    for code, g in df.groupby(v):
        dist.append({"measure": v, "code": code, "n": len(g), "share": round(len(g)/len(df), 3),
                     "circulation_rate": round(g.circ.mean(), 3)})
dist = pd.DataFrame(dist); dist.to_csv(os.path.join(OUT, "table2b_GSI_LSI_distribution.csv"), index=False)
log("\n=== Distribution and unadjusted circulation by code ===\n" + dist.to_string(index=False))

# ---------------------------------------------------------------- 4. Estimation helpers
G = df["kampung_id"]
def lpm(formula, data=df):
    return smf.ols(formula, data=data).fit(cov_type="cluster", cov_kwds={"groups": data["kampung_id"]}, use_t=True)
def probit(formula, data=df):
    with contextlib.redirect_stdout(io.StringIO()):
        return smf.probit(formula, data=data).fit(disp=0, maxiter=200, cov_type="cluster",
                                                  cov_kwds={"groups": data["kampung_id"]})
rows = []          # long-format store of every reported coefficient
def store(model_id, label, res, terms, kind="LPM", extra=None):
    for t in terms:
        ci = res.conf_int().loc[t]
        rows.append({"model": model_id, "label": label, "estimator": kind, "term": t,
                     "coef": res.params[t], "se": res.bse[t], "p": res.pvalues[t],
                     "ci_lo": ci[0], "ci_hi": ci[1], "N": int(res.nobs),
                     "clusters": G.nunique(), "r2": getattr(res, "rsquared", np.nan),
                     **(extra or {})})

# ---------------------------------------------------------------- 5. Principal models (Table 3)
specs = {
    "M1": ("GSI separately",          "circ ~ GSI01 + " + CTRL + FE, ["GSI01"]),
    "M2": ("LSI separately",          "circ ~ LSI01 + " + CTRL + FE, ["LSI01"]),
    "M3": ("GSI and LSI jointly",     "circ ~ GSI01 + LSI01 + " + CTRL + FE, ["GSI01", "LSI01"]),
    # categorical coding of the same items (robustness; reference = code 1)
    "M1c": ("GSI categorical",        "circ ~ C(GSI) + " + CTRL + FE, ["C(GSI)[T.2]", "C(GSI)[T.3]"]),
    "M2c": ("LSI categorical",        "circ ~ C(LSI) + " + CTRL + FE, ["C(LSI)[T.2]", "C(LSI)[T.3]"]),
    "M3c": ("GSI, LSI categorical jointly", "circ ~ C(GSI) + C(LSI) + " + CTRL + FE,
            ["C(GSI)[T.2]", "C(GSI)[T.3]", "C(LSI)[T.2]", "C(LSI)[T.3]"]),
    # secondary perceived-attitude items D3, D4 (1-7)
    "M4": ("D3 separately",           "circ ~ D3_village_attitude + " + CTRL + FE, ["D3_village_attitude"]),
    "M5": ("D4 separately",           "circ ~ D4_close_attitude + " + CTRL + FE, ["D4_close_attitude"]),
    "M6": ("D3 and D4 jointly",       "circ ~ D3_village_attitude + D4_close_attitude + " + CTRL + FE,
           ["D3_village_attitude", "D4_close_attitude"]),
    "M7": ("All four measures",       "circ ~ GSI01 + LSI01 + D3_village_attitude + D4_close_attitude + " + CTRL + FE,
           ["GSI01", "LSI01", "D3_village_attitude", "D4_close_attitude"]),
    # winsorised controls (1st/99th pct)
    "W1": ("GSI, winsorised controls", "circ ~ GSI01 + " + CTRL_W + FE, ["GSI01"]),
    "W2": ("LSI, winsorised controls", "circ ~ LSI01 + " + CTRL_W + FE, ["LSI01"]),
    "W3": ("Joint, winsorised controls", "circ ~ GSI01 + LSI01 + " + CTRL_W + FE, ["GSI01", "LSI01"]),
    "W6": ("D3 and D4, winsorised controls", "circ ~ D3_village_attitude + D4_close_attitude + " + CTRL_W + FE,
           ["D3_village_attitude", "D4_close_attitude"]),
}
FIT = {}
ctrl_terms = [t.strip() for t in CTRL.split("+")]
log("\n=== Linear probability models (case FE, SE clustered by kampung, t with G-1 df) ===")
for mid, (lab, f, terms) in specs.items():
    r = lpm(f); FIT[mid] = r
    store(mid, lab, r, terms)
    if mid in ("M1", "M2", "M3", "M4", "M5", "M6", "M7"): store(mid, lab, r, ctrl_terms)          # full control estimates for the SI
    if mid in ("M1c", "M2c", "M3c"):
        for v in ("GSI", "LSI"):
            names = [t for t in terms if t.startswith(f"C({v})")]
            if names:
                w = r.wald_test(" = 0, ".join(names) + " = 0", scalar=True)
                rows.append({"model": mid, "label": lab, "estimator": "Wald", "term": f"joint {v} codes",
                             "coef": np.nan, "se": np.nan, "p": float(w.pvalue), "N": int(r.nobs),
                             "F": float(w.statistic)})
    log(f"{mid:4s} {lab:32s} N={int(r.nobs)} R2={r.rsquared:.3f} " +
        "; ".join(f"{t}={r.params[t]:+.3f} (se {r.bse[t]:.3f}, p={r.pvalues[t]:.3f})" for t in terms))

# ---------------------------------------------------------------- 6. Probit with separation diagnostics
log("\n=== Probit (case FE, clustered SE), average marginal effects ===")
probit_specs = {k: specs[k] for k in ["M1", "M2", "M3", "M4", "M5", "M6"]}
diag = []
for mid, (lab, f, terms) in probit_specs.items():
    r = probit(f)
    xb = r.fittedvalues; ph = stats.norm.cdf(xb)
    cases_perfect = df.groupby("case")["circ"].agg(lambda s: s.nunique() == 1).sum()
    d = {"model": "P" + mid[1:], "label": lab, "converged": bool(r.mle_retvals.get("converged", False)),
         "max_abs_xb": float(np.abs(xb).max()), "n_p_lt_.01_or_gt_.99": int(((ph < .01) | (ph > .99)).sum()),
         "cases_with_no_outcome_variation": int(cases_perfect), "pseudo_r2": float(r.prsquared), "N": int(r.nobs)}
    # separation: non-convergence or a linear index large enough to imply (quasi-)perfect prediction
    d["separation_problem"] = (not d["converged"]) or d["max_abs_xb"] > 5
    diag.append(d)
    me = r.get_margeff(at="overall")
    mtab = me.summary_frame()
    for t in terms:
        rows.append({"model": d["model"], "label": lab + " (probit AME)", "estimator": "Probit AME", "term": t,
                     "coef": mtab.loc[t, "dy/dx"], "se": mtab.loc[t, "Std. Err."], "p": mtab.loc[t, "Pr(>|z|)"],
                     "ci_lo": mtab.loc[t, "Conf. Int. Low"], "ci_hi": mtab.loc[t, "Cont. Int. Hi."],
                     "N": int(r.nobs), "clusters": G.nunique(), "r2": r.prsquared})
    log(f"{d['model']:4s} {lab:24s} N={d['N']} converged={d['converged']} max|xb|={d['max_abs_xb']:.2f} "
        f"extreme p={d['n_p_lt_.01_or_gt_.99']} -> separation problem: {d['separation_problem']}; " +
        "; ".join(f"{t} AME={mtab.loc[t,'dy/dx']:+.3f} (p={mtab.loc[t,'Pr(>|z|)']:.3f})" for t in terms))
pd.DataFrame(diag).to_csv(os.path.join(OUT, "tableS4_probit_separation_diagnostics.csv"), index=False)

# ---------------------------------------------------------------- 7. Case-specific slopes
log("\n=== Case-specific slopes (interaction models) ===")
case_names = df.groupby("case")["city_name"].first()
slope_rows = []
for v in ["GSI01", "LSI01", "D3_village_attitude", "D4_close_attitude"]:
    f = f"circ ~ C(case)*{v} + " + CTRL
    r = lpm(f)
    inter = [p for p in r.params.index if p.startswith("C(case)[T.") and p.endswith(":" + v)]
    w = r.wald_test(" = 0, ".join(inter) + " = 0", scalar=True)
    for c in sorted(df.case.unique()):
        L = np.zeros(len(r.params)); L[list(r.params.index).index(v)] = 1
        if c != 1: L[list(r.params.index).index(f"C(case)[T.{c}]:{v}")] = 1
        tt = r.t_test(L); ci = np.asarray(tt.conf_int()).ravel()
        slope_rows.append({"measure": v, "case": c, "case_name": case_names[c],
                           "n": int((df.case == c).sum()), "slope": float(tt.effect.ravel()[0]),
                           "se": float(tt.sd.ravel()[0]), "p": float(tt.pvalue), "ci_lo": ci[0], "ci_hi": ci[1],
                           "equal_slopes_F": float(w.statistic), "equal_slopes_p": float(w.pvalue),
                           "N_model": int(r.nobs)})
    log(f"{v}: test of equal slopes across 7 cases F={float(w.statistic):.2f}, p={float(w.pvalue):.3f}, N={int(r.nobs)}")
slopes = pd.DataFrame(slope_rows); slopes.to_csv(os.path.join(OUT, "tableS5_case_specific_slopes.csv"), index=False)

# ---------------------------------------------------------------- 8. Exploratory spatial analysis
log("\n=== Exploratory spatial analysis (kampung level, n=42) ===")
cen = pd.read_csv(CEN)
assert (cen.set_index("kampung_id")["n"] == df.groupby("kampung_id").size()).all()
df["resid_M3"] = FIT["M3"].resid
df["circ_dm"] = df["circ"] - df.groupby("case")["circ"].transform("mean")    # case-demeaned
df["GSI_dm"] = df["GSI"] - df.groupby("case")["GSI"].transform("mean")
df["LSI_dm"] = df["LSI"] - df.groupby("case")["LSI"].transform("mean")
kam = df.groupby("kampung_id")[["resid_M3", "circ_dm", "GSI_dm", "LSI_dm"]].mean().join(cen.set_index("kampung_id"))
lat, lon = np.radians(kam.lat.values), np.radians(kam.lon.values)
dlat = lat[:, None] - lat[None, :]; dlon = lon[:, None] - lon[None, :]
D = 6371 * 2 * np.arcsin(np.sqrt(np.sin(dlat/2)**2 + np.cos(lat[:, None])*np.cos(lat[None, :])*np.sin(dlon/2)**2))
K = 3   # k=5 would make every neighbour set equal to the rest of the case (6 kampungs/case)
W = np.zeros_like(D)
for i in range(len(D)):
    W[i, np.argsort(D[i])[1:K+1]] = 1
W = W / W.sum(1, keepdims=True)
same_case = (kam.case.values[:, None] == kam.case.values[None, :])
log(f"k-nearest-neighbour weights, k={K}; share of neighbour links within the same case: {(W>0)[same_case].sum()/(W>0).sum():.2f}")
rng = np.random.default_rng(SEED)
groups = [np.where(kam.case.values == c)[0] for c in np.unique(kam.case.values)]
def perm_within_case(z):
    zp = z.copy()
    for g in groups: zp[g] = rng.permutation(z[g])
    return zp
def moran(x, W, nperm=9999):
    # conditional permutation within case: case-demeaned values are not exchangeable across cases
    z = x - x.mean(); I = len(z)/W.sum() * (z @ W @ z) / (z @ z)
    perm = np.array([(lambda zp: len(zp)/W.sum()*(zp @ W @ zp)/(zp @ zp))(perm_within_case(z)) for _ in range(nperm)])
    p = (1 + (np.abs(perm - perm.mean()) >= abs(I - perm.mean())).sum()) / (nperm + 1)
    return I, perm.mean(), p
sp = []
for v, lab in [("resid_M3", "Residual, joint model M3"), ("circ_dm", "Circulation (case-demeaned)"),
               ("GSI_dm", "GSI code (case-demeaned)"), ("LSI_dm", "LSI code (case-demeaned)")]:
    I, EI, p = moran(kam[v].values, W)
    sp.append({"variable": lab, "morans_I": round(I, 3), "expected_I": round(EI, 3), "perm_p_two_sided": round(p, 4),
               "n_kampungs": len(kam), "weights": f"kNN k={K}, row-standardised; within-case permutation (9999)"})
    log(f"{lab:32s} I={I:+.3f} (permutation mean={EI:+.3f}), permutation p={p:.3f}")
pd.DataFrame(sp).to_csv(os.path.join(OUT, "tableS6_spatial_morans_I.csv"), index=False)

# ---------------------------------------------------------------- 9. Write tables
est = pd.DataFrame(rows); est.to_csv(os.path.join(OUT, "all_estimates_long.csv"), index=False)
def cell(m, t):
    r = est[(est.model == m) & (est.term == t)]
    if r.empty: return ""
    r = r.iloc[0]; s = "***" if r.p < .01 else "**" if r.p < .05 else "*" if r.p < .1 else ""
    return f"{r.coef:.3f}{s} ({r.se:.3f})"
def table(models, terms, names, title, note):
    lines = [f"### {title}", "", "| | " + " | ".join(models) + " |", "|---|" + "---|"*len(models)]
    for t, nm in zip(terms, names): lines.append(f"| {nm} | " + " | ".join(cell(m, t) for m in models) + " |")
    Ns = [str(int(est[est.model == m].N.iloc[0])) for m in models]
    r2 = [f"{est[est.model == m].r2.iloc[0]:.3f}" for m in models]
    lines += ["| Controls / case FE | " + " | ".join(["Yes"]*len(models)) + " |",
              "| Observations | " + " | ".join(Ns) + " |", "| Kampung clusters | " + " | ".join(["42"]*len(models)) + " |",
              "| R² (pseudo-R² for probit) | " + " | ".join(r2) + " |", "", note, ""]
    return "\n".join(lines)
NOTE = ("Linear probability models of circulation (1 = circulated, decided or likely). Coefficients with standard errors "
        "clustered by kampung in parentheses; t inference with 41 df. GSI and LSI are the field-administered three-level "
        "codes rescaled to 0, 0.5, 1, so each coefficient is the adjusted difference between code 3 and code 1. "
        "D3 and D4 are seven-point perceived-attitude items (1 = strongly disagree ... 7 = strongly agree). "
        "*** p<0.01, ** p<0.05, * p<0.1.")
md = ["# Regression tables (generated by reanalysis.py)", "",
      table(["M1", "M2", "M3"], ["GSI01", "LSI01"], ["GSI (code 3 vs 1)", "LSI (code 3 vs 1)"],
            "Table 3, models 1–3. GSI and LSI and circulation", NOTE),
      table(["M1c", "M2c", "M3c"], ["C(GSI)[T.2]", "C(GSI)[T.3]", "C(LSI)[T.2]", "C(LSI)[T.3]"],
            ["GSI code 2 (vs 1)", "GSI code 3 (vs 1)", "LSI code 2 (vs 1)", "LSI code 3 (vs 1)"],
            "Table S3, panel C. Categorical coding of GSI and LSI", NOTE + " Reference category is code 1. Joint Wald tests in all_estimates_long.csv."),
      table(["M4", "M5", "M6", "M7"], ["D3_village_attitude", "D4_close_attitude", "GSI01", "LSI01"],
            ["D3 perceived village attitude (1–7)", "D4 perceived close-network attitude (1–7)", "GSI (code 3 vs 1)", "LSI (code 3 vs 1)"],
            "Table 3, models 4–7. Secondary perceived-attitude items D3 and D4", NOTE),
      table(["W1", "W2", "W3", "W6"], ["GSI01", "LSI01", "D3_village_attitude", "D4_close_attitude"],
            ["GSI (code 3 vs 1)", "LSI (code 3 vs 1)", "D3 (1–7)", "D4 (1–7)"],
            "Table S3, panel D. Winsorised continuous controls (1st/99th percentiles)", NOTE),
      table(["P1", "P2", "P3", "P4", "P5", "P6"], ["GSI01", "LSI01", "D3_village_attitude", "D4_close_attitude"],
            ["GSI (code 3 vs 1)", "LSI (code 3 vs 1)", "D3 (1–7)", "D4 (1–7)"],
            "Table S4. Probit average marginal effects",
            "Probit with case fixed effects; average marginal effects with kampung-clustered delta-method SEs (normal inference). "
            "Separation diagnostics in tableS4_probit_separation_diagnostics.csv."),
      table(["M3", "M7"], ctrl_terms, ctrl_terms, "Table S3. Full control estimates", NOTE)]
open(os.path.join(OUT, "regression_tables.md"), "w").write("\n".join(md))

# ---------------------------------------------------------------- 10. Figures
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False})
# Fig 3: circulation by code
fig, ax = plt.subplots(1, 2, figsize=(7.5, 3), sharey=True)
for a, v in zip(ax, ["GSI", "LSI"]):
    s = dist[dist.measure == v]
    p = s.circulation_rate.values; n = s.n.values
    z = 1.96; ctr = (p + z*z/(2*n))/(1+z*z/n); hw = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/(1+z*z/n)
    a.bar(s.code.astype(str), p, color="#4C72B0", alpha=.8); a.errorbar(s.code.astype(str), ctr, yerr=hw, fmt="none", ecolor="k", capsize=3)
    for x, (pp, nn) in enumerate(zip(p, n)): a.text(x, 0.03, f"n={nn}", ha="center", color="white", fontsize=8)
    a.set_title(f"{v} code"); a.set_xlabel("Field code"); a.set_ylim(0, .8)
ax[0].set_ylabel("Share circulating (95% Wilson CI)")
fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig3_circulation_by_GSI_LSI_code.png"), dpi=300); plt.close()
# Fig 4: standardised coefficient plot
fig, ax = plt.subplots(figsize=(6, 3))
items = [("M1", "GSI01", "GSI (M1)"), ("M2", "LSI01", "LSI (M2)"), ("M3", "GSI01", "GSI (M3, joint)"), ("M3", "LSI01", "LSI (M3, joint)"),
         ("M4", "D3_village_attitude", "D3 (M4)"), ("M5", "D4_close_attitude", "D4 (M5)"),
         ("M6", "D3_village_attitude", "D3 (M6, joint)"), ("M6", "D4_close_attitude", "D4 (M6, joint)")]
for i, (m, t, lab) in enumerate(items):
    r = est[(est.model == m) & (est.term == t)].iloc[0]; sd = df[t].std()
    ax.errorbar(r.coef*sd, i, xerr=[[ (r.coef-r.ci_lo)*sd ], [ (r.ci_hi-r.coef)*sd ]], fmt="o", color="#333", capsize=2)
ax.axvline(0, color="grey", lw=.8, ls="--"); ax.set_yticks(range(len(items))); ax.set_yticklabels([x[2] for x in items]); ax.invert_yaxis()
ax.set_xlabel("Change in circulation probability per 1 SD (95% CI)")
fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig4_coefficients_per_SD.png"), dpi=300); plt.close()
# Fig 5: case-specific slopes
fig, ax = plt.subplots(1, 2, figsize=(8, 3.2), sharey=True)
for a, v, lab in zip(ax, ["GSI01", "LSI01"], ["GSI (code 3 vs 1)", "LSI (code 3 vs 1)"]):
    s = slopes[slopes.measure == v]
    a.errorbar(s.slope, range(7), xerr=[s.slope - s.ci_lo, s.ci_hi - s.slope], fmt="o", color="#333", capsize=2)
    a.axvline(0, color="grey", lw=.8, ls="--"); a.set_title(f"{lab}\nequal-slopes p = {s.equal_slopes_p.iloc[0]:.2f}")
ax[0].set_yticks(range(7)); ax[0].set_yticklabels([f"{c}. {n.split(',')[0]}" for c, n in case_names.items()]); ax[0].invert_yaxis()
fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig5_case_specific_slopes.png"), dpi=300); plt.close()
# Fig 6: Moran scatter
z = kam.resid_M3.values - kam.resid_M3.mean(); lag = W @ z
fig, ax = plt.subplots(figsize=(3.6, 3.4))
ax.scatter(z, lag, s=14, c=kam.case, cmap="tab10"); b = np.polyfit(z, lag, 1); xx = np.linspace(z.min(), z.max(), 10)
ax.plot(xx, np.polyval(b, xx), "k-", lw=.8); ax.axhline(0, c="grey", lw=.5); ax.axvline(0, c="grey", lw=.5)
ax.set_xlabel("Kampung mean residual (M3)"); ax.set_ylabel("Spatial lag")
ax.set_title(f"Moran's I = {sp[0]['morans_I']:.3f}, p = {sp[0]['perm_p_two_sided']:.2f}", fontsize=9)
fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig6_moran_scatter_residuals.png"), dpi=300); plt.close()


# ---------------------------------------------------------------- 11. Further quantities reported in the paper
import json
from statsmodels.stats.outliers_influence import variance_inflation_factor
from patsy import dmatrices
ST = {}
T41 = stats.t.ppf(.975, 41) + stats.t.ppf(.80, 41)          # multiplier for 80% power, two-sided 5%, 41 df
def E(m, t): return est[(est.model == m) & (est.term == t)].iloc[0]
def wald(m, names):
    r = FIT[m]; w = r.wald_test(" = 0, ".join(names) + " = 0", scalar=True); return float(w.statistic), float(w.pvalue)

# (a) VIFs for the social-interaction measures
for m in ["M3", "M7"]:
    y, X = dmatrices(specs[m][1], df, return_type="dataframe")
    ST[f"vif_{m}"] = {t: float(variance_inflation_factor(X.values, list(X.columns).index(t))) for t in specs[m][2]}
# (b) effects per SD (continuous) or 0->1 (binary), model M3 and D3/D4 from M6
binv = {"marriage_status", "religious_belief", "self_evaluated_health", "occ_byb", "occ_nonfarm",
        "household_splitting_son", "land_mgmt_right_circulation"}
eff = []
for m, terms in [("M3", ["GSI01", "LSI01"] + ctrl_terms), ("M6", ["D3_village_attitude", "D4_close_attitude"])]:
    r = FIT[m]
    for t in terms:
        sc = 1.0 if t in binv else df[t].std()
        ci = r.conf_int().loc[t]
        eff.append({"model": m, "term": t, "scale": "0 to 1" if t in binv else "1 SD", "sd": df[t].std(),
                    "effect_pp": 100*r.params[t]*sc, "lo_pp": 100*ci[0]*sc, "hi_pp": 100*ci[1]*sc, "p": r.pvalues[t]})
eff = pd.DataFrame(eff); eff.to_csv(os.path.join(OUT, "fig4_effects_data.csv"), index=False)
# (c) bounded coding of age and wealth (Table S3 panel B)
df["age_band"] = pd.cut(df.age, [0, 34, 44, 54, 64, 69, 200], labels=["<35", "35-44", "45-54", "55-64", "65-69", "70 (top-coded)"])
CTRL_AB = CTRL.replace("age + ", "C(age_band) + ")
sub = df[(df.age_topcoded == 0) & (df.wealth_floor == 0)]
pb = []
for lab, rhs, data in [("Baseline", CTRL, df), ("Age in bands, top-coded category", CTRL_AB, df),
                       ("Adds wealth-floor indicator", CTRL + " + wealth_floor", df),
                       ("Excludes top-coded age and floored wealth", CTRL, sub)]:
    for key, xs in [("GSI_LSI", "GSI01 + LSI01"), ("D3_D4", "D3_village_attitude + D4_close_attitude")]:
        r = lpm(f"circ ~ {xs} + {rhs}{FE}", data)
        for t in xs.split(" + "):
            pb.append({"spec": lab, "block": key, "term": t, "coef": r.params[t], "se": r.bse[t], "p": r.pvalues[t], "N": int(r.nobs)})
        if lab.startswith("Age in bands") and key == "GSI_LSI":
            ST["age_bands"] = {k: {"coef": float(r.params[k]), "p": float(r.pvalues[k])} for k in r.params.index if "age_band" in k}
pb = pd.DataFrame(pb); pb.to_csv(os.path.join(OUT, "tableS3B_bounded_coding.csv"), index=False)
# (d) East Malaysia interaction
df["east"] = (df.case >= 5).astype(int)
for v in ["GSI01", "LSI01", "D3_village_attitude", "D4_close_attitude"]:
    r = lpm(f"circ ~ {v} + {v}:east + {CTRL}{FE}"); t = f"{v}:east"
    ST[f"east_{v}"] = {"coef": float(r.params[t]), "se": float(r.bse[t]), "p": float(r.pvalues[t]), "N": int(r.nobs),
                       "mde": float(T41*r.bse[t])}
# (e) wild cluster bootstrap (restricted, Rademacher, 999) for equality of the seven case slopes
def wcr_equal_slopes(v, B=999):
    fu = f"circ ~ C(case)*{v} + " + CTRL; fr = f"circ ~ C(case) + {v} + " + CTRL
    yu, Xu = dmatrices(fu, df, return_type="dataframe"); _, Xr = dmatrices(fr, df, return_type="dataframe")
    names = [c for c in Xu.columns if c.startswith("C(case)[T.") and c.endswith(":" + v)]
    Xu_, Xr_, y_ = Xu.values, Xr.values, yu.values.ravel()
    g = df.kampung_id.values; ug = np.unique(g); gi = np.searchsorted(ug, g)
    R = np.zeros((len(names), Xu_.shape[1])); [R.__setitem__((i, list(Xu.columns).index(n)), 1) for i, n in enumerate(names)]
    XtXi = np.linalg.inv(Xu_.T @ Xu_); G_ = len(ug); n_, k_ = Xu_.shape
    cfac = G_/(G_-1)*(n_-1)/(n_-k_)
    def Fstat(y):
        b = XtXi @ Xu_.T @ y; e = y - Xu_ @ b
        S = np.zeros((G_, k_)); np.add.at(S, gi, Xu_*e[:, None])
        V = cfac * XtXi @ (S.T @ S) @ XtXi; Rb = R @ b
        return float(Rb @ np.linalg.solve(R @ V @ R.T, Rb) / len(names))
    F0 = Fstat(y_)
    br = np.linalg.lstsq(Xr_, y_, rcond=None)[0]; fit_r = Xr_ @ br; er = y_ - fit_r
    rngb = np.random.default_rng(SEED)
    Fb = np.array([Fstat(fit_r + er*rngb.choice([-1, 1], G_)[gi]) for _ in range(B)])
    return F0, float((1 + (Fb >= F0).sum())/(B + 1))
for v in ["GSI01", "LSI01", "D3_village_attitude", "D4_close_attitude"]:
    F0, pw = wcr_equal_slopes(v); ST[f"slopes_{v}"] = {"F": F0, "p_conv": float(slopes[slopes.measure == v].equal_slopes_p.iloc[0]), "p_wild": pw}
    log(f"Equal-slopes {v}: F={F0:.2f}, conventional p={ST[f'slopes_{v}']['p_conv']:.3f}, wild cluster bootstrap p={pw:.3f}")
slopes["wild_bootstrap_p"] = slopes.measure.map(lambda v: ST[f"slopes_{v}"]["p_wild"])
slopes.to_csv(os.path.join(OUT, "tableS5_case_specific_slopes.csv"), index=False)
# (f) circulation by case, chi-square, ICC of circulation
cc = df.groupby("case").circ.agg(["sum", "size", "mean"])
z = 1.96; n_ = cc["size"]; p_ = cc["mean"]
cc["lo"] = (p_ + z*z/(2*n_) - z*np.sqrt(p_*(1-p_)/n_ + z*z/(4*n_*n_)))/(1+z*z/n_)
cc["hi"] = (p_ + z*z/(2*n_) + z*np.sqrt(p_*(1-p_)/n_ + z*z/(4*n_*n_)))/(1+z*z/n_)
cc.to_csv(os.path.join(OUT, "case_circulation_rates.csv"))
chi = stats.chi2_contingency(pd.crosstab(df.case, df.circ)); ST["case_chi2"] = {"chi2": float(chi[0]), "df": int(chi[2]), "p": float(chi[1])}
k = df.groupby("kampung_id").size(); n0 = (len(df) - (k**2).sum()/len(df))/(len(k)-1); gm = df.groupby("kampung_id").circ
msb = (k*(gm.mean()-df.circ.mean())**2).sum()/(len(k)-1); msw = ((df.circ-gm.transform("mean"))**2).sum()/(len(df)-len(k))
ST["icc_circ"] = float((msb-msw)/(msb+(n0-1)*msw)); ST["mean_kampung_size"] = float(k.mean())
for v in ["GSI", "LSI"]:
    gv = df.groupby("kampung_id")[v]; msb = (k*(gv.mean()-df[v].mean())**2).sum()/(len(k)-1); msw = ((df[v]-gv.transform("mean"))**2).sum()/(len(df)-len(k))
    ST[f"icc_{v}"] = float((msb-msw)/(msb+(n0-1)*msw)); ST[f"kampungs_varying_{v}"] = int((gv.nunique() > 1).sum())
    ST[f"chi2_kampung_{v}"] = float(stats.chi2_contingency(pd.crosstab(df.kampung_id, df[v]))[1])
# (g) MDEs, correlations, distributions, joint tests
for m, t in [("M1", "GSI01"), ("M2", "LSI01"), ("M4", "D3_village_attitude"), ("M5", "D4_close_attitude")]:
    ST[f"mde_{t}"] = float(T41*E(m, t).se)
ST["spearman"] = {"GSI_LSI": float(stats.spearmanr(df.GSI, df.LSI)[0]), "GSI_D3": float(stats.spearmanr(df.GSI, df.D3_village_attitude)[0]),
                  "LSI_D4": float(stats.spearmanr(df.LSI, df.D4_close_attitude)[0]), "D3_D4": float(stats.spearmanr(df.D3_village_attitude, df.D4_close_attitude)[0])}
for v in ["D3_village_attitude", "D4_close_attitude"]:
    ST[f"dist_{v}"] = {"disagree_1_3": float((df[v] <= 3).mean()), "unable_4": float((df[v] == 4).mean()), "agree_5_7": float((df[v] >= 5).mean()),
                       "mean": float(df[v].mean()), "sd": float(df[v].std())}
for m, v in [("M1c", "GSI"), ("M2c", "LSI"), ("M3c", "GSI"), ("M3c", "LSI")]:
    ST[f"joint_{m}_{v}"] = dict(zip(["F", "p"], wald(m, [f"C({v})[T.2]", f"C({v})[T.3]"])))
ST["joint_M6_D3D4"] = dict(zip(["F", "p"], wald("M6", ["D3_village_attitude", "D4_close_attitude"])))
ST["n"] = len(df); ST["n_excl_bounded"] = int(len(sub)); ST["age_topcoded"] = int(df.age_topcoded.sum()); ST["wealth_floor"] = int(df.wealth_floor.sum())
ST["occ_counts"] = df.occupation_category.value_counts().sort_index().to_dict()
ST["spatial"] = sp; ST["probit_diag"] = diag
json.dump(ST, open(os.path.join(OUT, "manuscript_stats.json"), "w"), indent=1, default=float)

# ---------------------------------------------------------------- 12. Paper figures 3-5
lab_case = {c: n.split(",")[0].replace(" District", "") for c, n in case_names.items()}
fig, ax = plt.subplots(2, 2, figsize=(8, 6))
a = ax[0, 0]; a.bar([lab_case[c] for c in cc.index], cc["mean"], color="#4C72B0", alpha=.85)
a.errorbar(range(7), (cc.lo+cc.hi)/2, yerr=(cc.hi-cc.lo)/2, fmt="none", ecolor="k", capsize=2)
a.axhline(df.circ.mean(), ls="--", c="grey", lw=.8); a.set_ylabel("Share circulating"); a.set_title("(a) Circulation by case (95% Wilson CI)")
a.tick_params(axis="x", rotation=45, labelsize=7)
a = ax[0, 1]; oc = df.occupation_category.value_counts().sort_index()
a.bar(["Farming", "By-business", "Non-farm"], oc.values, color="#55A868"); a.set_ylabel("Households"); a.set_title("(b) Occupation of household head")
a = ax[1, 0]; w = .38; codes = np.array([1, 2, 3])
for j, (v, col) in enumerate([("GSI", "#4C72B0"), ("LSI", "#DD8452")]):
    cnt = df[v].value_counts().reindex(codes, fill_value=0); a.bar(codes + (j-.5)*w, cnt.values, w, label=v, color=col)
a.set_xticks(codes); a.set_xticklabels(["Negative", "Neutral", "Positive"]); a.set_ylabel("Households"); a.legend(frameon=False)
a.set_title("(c) Perceived village (GSI) and close-network (LSI) attitude")
a = ax[1, 1]; lv = np.arange(1, 8)
for j, (v, lab, col) in enumerate([("D3_village_attitude", "D3", "#4C72B0"), ("D4_close_attitude", "D4", "#DD8452")]):
    cnt = df[v].value_counts().reindex(lv, fill_value=0); a.bar(lv + (j-.5)*w, cnt.values, w, label=lab, color=col)
a.set_xticks(lv); a.set_xlabel("1 = strongly disagree ... 4 = unable to judge ... 7 = strongly agree", fontsize=7)
a.set_ylabel("Households"); a.legend(frameon=False); a.set_title("(d) Agreement with D3 and D4")
fig.tight_layout(); fig.savefig(os.path.join(OUT, "Figure3_sample.png"), dpi=300); plt.close()

names_fig = {"GSI01": "GSI: positive vs negative", "LSI01": "LSI: positive vs negative", "D3_village_attitude": "D3 (per SD, model 6)",
             "D4_close_attitude": "D4 (per SD, model 6)", "age": "Age", "educational_background": "Education",
             "marriage_status": "Married", "religious_belief": "Religious belief", "self_evaluated_health": "Healthy",
             "city_living_period_yr": "City living period", "occ_byb": "By-business (vs farming)", "occ_nonfarm": "Non-farm (vs farming)",
             "family_scale": "Family size", "household_splitting_son": "Household splitting of son",
             "family_net_wealth_MYR10k": "Net wealth", "homestead_area_m2": "Homestead area", "land_mgmt_right_circulation": "Agric. land right circulation"}
ef = eff.copy()
ef.loc[ef.term.isin(["GSI01", "LSI01"]), ["effect_pp", "lo_pp", "hi_pp"]] = ef.loc[ef.term.isin(["GSI01", "LSI01"]), ["effect_pp", "lo_pp", "hi_pp"]].values / ef.loc[ef.term.isin(["GSI01", "LSI01"]), ["sd"]].values
fig, ax = plt.subplots(figsize=(6.5, 5))
for i, r in ef.reset_index(drop=True).iterrows():
    col = "#C44E52" if r.p < .05 else "#333"; mk = "o" if r.p < .05 else "o"
    ax.errorbar(r.effect_pp, i, xerr=[[r.effect_pp-r.lo_pp], [r.hi_pp-r.effect_pp]], fmt=mk, color=col, mfc=col if r.p < .05 else "white", capsize=2)
ax.axvline(0, c="grey", lw=.8, ls="--"); ax.set_yticks(range(len(ef))); ax.set_yticklabels([names_fig[t] for t in ef.term], fontsize=8); ax.invert_yaxis()
ax.set_xlabel("Change in circulation probability, percentage points (95% CI)")
fig.tight_layout(); fig.savefig(os.path.join(OUT, "Figure4_associations.png"), dpi=300); plt.close()

fig, ax = plt.subplots(1, 4, figsize=(10, 3.4), sharey=True)
for a, v, lab in zip(ax, ["GSI01", "LSI01", "D3_village_attitude", "D4_close_attitude"],
                     ["(a) GSI, positive vs negative", "(b) LSI, positive vs negative", "(c) D3, per scale point", "(d) D4, per scale point"]):
    s = slopes[slopes.measure == v]
    a.errorbar(s.slope, range(7), xerr=[s.slope-s.ci_lo, s.ci_hi-s.slope], fmt="o", color="#333", capsize=2)
    a.axvline(0, c="grey", lw=.8, ls="--"); a.axvline(E({"GSI01": "M1", "LSI01": "M2", "D3_village_attitude": "M4", "D4_close_attitude": "M5"}[v], v).coef, c="#4C72B0", lw=.8)
    a.axhspan(3.5, 6.5, color="grey", alpha=.08)
    a.set_title(f"{lab}\nconv. p = {ST[f'slopes_{v}']['p_conv']:.3f}; bootstrap p = {ST[f'slopes_{v}']['p_wild']:.3f}", fontsize=8)
ax[0].set_yticks(range(7)); ax[0].set_yticklabels([f"{c}. {lab_case[c]}" for c in case_names.index], fontsize=8); ax[0].invert_yaxis()
fig.tight_layout(); fig.savefig(os.path.join(OUT, "Figure5_case_slopes.png"), dpi=300); plt.close()
log("Paper statistics written.")
open(os.path.join(OUT, "analysis_log.txt"), "w").write(LOG.getvalue())

# ---------------------------------------------------------------- 13. Questionnaire-variable mapping (data dictionary)
R = [
("survey_id","survey_id","Sec A: Survey ID / Questionnaire No.","Integer 1–369","Identifier","Unique; no duplicates"),
("city_fe","case","Sec A: Survey Area (1–7)","1 FELDA Serting Hilir; 2 Baling; 3 Permatang Pauh; 4 Mersing; 5 Ranau; 6 Kg. Sinulihan; 7 Kapit","Case fixed effects","52–53 households per case"),
("city_name","city_name","Sec A: Survey Area (label)","Text","Label only",""),
("region_fe","region_fe","Sec A: Geographic Region","Codes used: 1 Northern, 2 Central, 3 Southern Peninsula, 6 Sabah, 7 Sarawak","Not used","Nested within case; absorbed by case fixed effects"),
("region_name","region_name","Sec A: Geographic Region (label)","Text","Label only",""),
("kampung_id","kampung_id","Sec A: Survey Location / Kampung (anonymised)","Integer 1–42, nested in case","Cluster for SEs; spatial unit","4–15 households per kampung; counts match centroid file"),
("circulation_DV","circ","Sec C Q1","1 = has circulated, decided or likely to circulate; 0 = not","Outcome","Mean 0.436"),
("GSI","GSI; GSI01","Sec D Q1 (village item), as administered","Three-level rating: 1 negative, 2 neutral, 3 positive; GSI01 = (GSI − 1)/2","Principal measure","Not the questionnaire's computed score (0–0.5); varies within 41 of 42 kampungs (respondent-level rating)"),
("LSI","LSI; LSI01","Sec D Q2 (close-network item), as administered","As GSI; LSI01 = (LSI − 1)/2","Principal measure","Not the questionnaire's computed score (0–1); 11 respondents in category 3"),
("likert_overall_avg_expectation","D3_village_attitude","Sec D Q3 (D3): “The majority of farmers in this village/kampung have a positive attitude toward circulating residential land use rights.”","1 Strongly Disagree … 4 Unable to Judge … 7 Strongly Agree","Secondary measure","Perceived attitude, not expected behaviour; source column name misleading"),
("likert_closegroup_expectation","D4_close_attitude","Sec D Q4 (D4): “My relatives, friends, and neighbours in this village have a positive attitude toward the circulation of residential land use rights.”","As D3","Secondary measure","As D3"),
("age","age","Sec B Q1","Years; top-coded at 70","Control","25 heads at 70"),
("educational_background","educational_background","Sec B Q3","Years of schooling, 0–14","Control",""),
("marriage_status","marriage_status","Sec B Q5","1 married; 0 single, divorced or widowed","Control",""),
("religious_belief","religious_belief","Sec B Q6","1 religious belief; 0 none","Control",""),
("self_evaluated_health","self_evaluated_health","Sec B Q7","1 healthy; 0 not healthy or unsure","Control",""),
("city_living_period_yr","city_living_period_yr","Sec B Q8","Years lived in a town or city","Control",""),
("occupation_category","occ_byb; occ_nonfarm","Sec B Q9","1 pure farming (ref.); 2 by-business; 3 non-farm","Control (two indicators)","160 / 129 / 80"),
("family_scale","family_scale","Sec B Q10","Household members, 2–6","Control",""),
("household_splitting_son","household_splitting_son","Sec B Q11","1 splitting required; 0 not","Control",""),
("family_net_wealth_MYR10k","family_net_wealth_MYR10k","Sec B Q12","MYR 10,000; bounded below at 1.00","Control","34 households at 1.00"),
("homestead_area_m2","homestead_area_m2","Sec E Q1","m², building plus courtyard","Control",""),
("land_mgmt_right_circulation","land_mgmt_right_circulation","Sec E Q2","1 agricultural land management right has been, will be or is likely to be circulated; 0 not","Control",""),
("lat, lon (centroid file)","lat, lon","Not a questionnaire item; approximate kampung centroids","Decimal degrees","Spatial weights only","Approximate"),
]
pd.DataFrame(R, columns=["source_column", "analysis_variable", "questionnaire_item", "coding", "role_in_models", "audit_note"]).to_csv(os.path.join(OUT, "data_dictionary.csv"), index=False)
log("\nDone. Outputs in " + OUT)
