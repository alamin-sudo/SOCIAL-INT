# Data audit note: verified analysis file and the construction of GSI and LSI

This note documents how the analysis file was verified before estimation and how the GSI and LSI measures were generated. Every figure here is produced by `code/reanalysis.py` and logged in `outputs/analysis_log.txt` and `outputs/manuscript_stats.json`.

## 1. Source file and cleaning

The analysis file is `data/raw/households-2_with_gsis_-_AQ.csv`. The project lead prepared it from the project's original data file and supplied it as the file of record.

| File | SHA-256 |
|---|---|
| `households-2_with_gsis_-_AQ.csv` | `adf7fa75d7d23a116911b772393e38c887a414c65d8e210cbc667b3019fbe4b8` |
| `kampung_centroids_approx_-AQ.csv` | `a30ee032e61916cd30dfbfc107b8b15f170e113ba3a3c97d1784fc55872083cd` |

The raw files are never modified. `reanalysis.py` applies the following steps and nothing else.

1. **Encoding.** The file is read as Windows-1252/latin-1, because it is not valid UTF-8.
2. **Rows removed.** Ten non-respondent rows (blank rows and appended notes) are dropped, leaving 369 respondents.
3. **Checks asserted in code.** Survey IDs are unique and there are no missing values. Every kampung lies in exactly one case, and every case lies in exactly one region. Household counts per kampung match the centroid file.
4. **Renaming.** `city_fe` becomes `case`, and `circulation_DV` becomes `circ`. `likert_overall_avg_expectation` becomes `D3_village_attitude`, and `likert_closegroup_expectation` becomes `D4_close_attitude`. The old names describe D3 and D4 as expectation items, which they are not.
5. **Derived variables.**
   - `GSI01` = (GSI − 1)/2 and `LSI01` = (LSI − 1)/2.
   - Occupation indicators, with pure farming as the reference.
   - Flags for top-coded age (age = 70, 25 heads) and floored wealth (1.00, 34 households).
   - Winsorised copies of the six continuous controls, at the 1st and 99th percentiles.

## 2. How GSI and LSI were generated

**Questionnaire design.** Items D1 and D2 were planned as headcounts. The scores were to be computed as:

- GSI = 0.5 × N_fav / (N_fav + N_neu/neg), from the kampung register, with a range of 0–0.5;
- LSI = n_fav / (n_fav + n_neu/neg), from the respondent's close network, with a range of 0–1.

**Field administration.** According to the project lead, the headcount format could not be implemented reliably. Counts conflicted, and many respondents were older heads; 37 heads (10.0%) were aged 65 or over. The items were therefore administered as single three-level ratings: 1 = negative, 2 = neutral, 3 = positive.

**What the file shows:**

| | GSI | LSI |
|---|---|---|
| Values present | 1, 2, 3 only | 1, 2, 3 only |
| Distribution (1 / 2 / 3) | 209 / 144 / 16 | 217 / 141 / 11 |
| Kampungs with more than one value | 41 of 42 | 41 of 42 |
| Kampung-level ICC | 0.008 | 0.024 |
| χ² test across kampungs, p (approximate) | 0.65 | 0.28 |

**Interpretation.**

1. **GSI was recorded separately for each respondent.** It is a respondent-level perception rating, which is why it varies within kampungs. A register count would be constant within each kampung.
2. **It was administered differently from the questionnaire.** It is a three-level rating, not the computed share.
3. **The file contains no computed score.** No counts were recorded, so the formula-based scores cannot be reconstructed.
4. **There is no sign of a data-entry error in the verified file.** All values lie in the permitted range, and the distributions are plausible.

**Consequence.** The paper reports GSI and LSI as perceived-attitude ratings throughout. The principal models use the linear coding (0, 0.5, 1). The categorical coding is a robustness check.

## 3. Comparison with earlier working versions

An earlier working draft of the paper reported GSI and LSI distributions that differ from the verified file:

| | Negative | Neutral | Positive |
|---|---|---|---|
| GSI, earlier draft | 29.3% | 53.9% | 16.8% |
| GSI, verified | 56.6% | 39.0% | 4.3% |
| LSI, earlier draft | 17.9% | 59.6% | 22.5% |
| LSI, verified | 58.8% | 38.2% | 3.0% |

Every other statistic in that draft matches the verified file to the reported precision. This covers the circulation rate (0.436), the age and wealth bounding counts, the D3 and D4 associations (7.1 and 8.3–8.4 points per SD), and all control estimates (for example, age −13.5 points per SD and by-business +13.9 points). The two versions therefore differ only in the GSI and LSI columns. The working file behind that draft was not available for row-level comparison, and none of its GSI or LSI estimates is used.

Two other files were found among the project's working files. Neither can be reconciled with the verified data, so neither is used:

- **A household file with continuous GSI and LSI.** Its control variables match none of the verified households.
- **The descriptive tables of an earlier manuscript version.** They use different variable definitions, case sizes and GSI ranges.

The continuous GSI and LSI values reported in earlier versions could not be traced to recorded field data or reproduced. They have been withdrawn.

## 4. Other measures

- **D3 and D4** are seven-point perceived-attitude items (1 = strongly disagree, 4 = unable to judge, 7 = strongly agree). They are nearly uncorrelated with GSI and LSI:
  - D3 with GSI: ρ = 0.03;
  - D4 with LSI: ρ = −0.11;
  - D3 with D4: ρ = 0.05.
- **Region** is nested within case, so the case fixed effects absorb it.
