#!/usr/bin/env bash
# Reproduces every estimate, results table and figure of the paper from the verified household data.
set -euo pipefail
cd "$(dirname "$0")"
python code/reanalysis.py                  # estimates, tables, Figures 3-5 (about 1-2 minutes)
python code/fig1_conceptual_framework.py   # Figure 1 (no data used)
python code/fig2_study_location.py         # Figure 2 (case centroids + Natural Earth extracts in data/external/)
echo "Done: outputs/ and data/processed/ regenerated."
